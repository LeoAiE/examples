# Change Log — Complete Record Across All Sessions

---

## MASTER FILE LIST: Every File Changed (22 unique files + 3 new)

### Session 1: Error Handling + Concurrent Execution
| # | File | Change |
|---|------|--------|
| 1 | `V2/backend/llm_provider.py` | LLMError exception + retry with exponential backoff |
| 2 | `V2/backend/tools/shared/tool_calling_engine.py` | Error detection, SSE events, no-data early exit, guidelines |
| 3 | `V2/backend/agents/base_agent.py` | Error propagation + thread-safe DB lazy load |
| 4 | `V2/backend/agents/orchestrator.py` | Concurrent ThreadPoolExecutor, error handling, new tools, self-query redirect, normalized search |
| 5 | `V2/backend/tools/shared/report_synthesizer.py` | Error filtering (_is_error_result) |
| 6 | `V2/backend/tools/shared/sub_agent_processor.py` | Better error logging |
| 7 | `V2/backend/tools/database_connectors/text_file_connector.py` | Path leakage fix |
| 8 | `V2/backend/tools/database_connectors/json_connector.py` | Path leakage fix |
| 9 | `V2/frontend/index.html` | SSE events, re-run UI, schedule controls |

### Session 2: Selective Re-run + Scheduling
| # | File | Change |
|---|------|--------|
| 10 | `V2/backend/agents/leo_manager.py` | Concurrent + selective re-run + save lock |
| 11 | `V2/backend/agents/targeting_manager.py` | Concurrent + selective re-run + save lock |
| 12 | `V2/backend/api_server.py` | 6 rerun/schedule endpoints, pipeline TTL, input validation |

### Session 3: Audit Fixes
| # | File | Change |
|---|------|--------|
| 13 | `V2/backend/tools/shared/target_store.py` | SQLite race condition locks (_write_lock) |
| 14 | `V2/backend/tools/shared/event_bus.py` | Thread safety (locks) + memory leak cleanup |
| 15 | `V2/backend/tools/shared/targeting_report_synthesizer.py` | Error filtering (_is_error_result) |
| 16 | `V2/backend/tools/shared/agent_query_tool.py` | Thread-safe recursion guard + DB load |

### Session 4: DateTime + SIGINT Correlation
| # | File | Change |
|---|------|--------|
| 17 | `V2/backend/tools/shared/datetime_tool.py` | **NEW** — current date/time + range calculations |
| 18 | `V2/backend/tools/agent_specific/sigint/correlation_tool.py` | **NEW** — two-stage Phone/IMEI/IMSI correlation |
| 19 | `V2/backend/data/correlation_db.txt` | **NEW** — 18 sample correlation records |
| 20 | `V2/backend/config.py` | Added CORRELATION_DB path |
| 21 | `V2/backend/tools/tool_definitions.py` | Added get_datetime + correlate_identifiers schemas |

---

## API/DATABASE MIGRATION GUIDE

### What Changes When You Swap Text Files for Real APIs

**The architecture has a clean adapter pattern.** Only 5 files need to change — everything else stays identical.

### THE 5 FILES THAT CHANGE:

#### 1. `V2/backend/agents/base_agent.py` — `load_database()` method (line ~195)
```
CURRENT:  open(self.db_path, "r") → reads .txt file into self.database_content
CHANGE:   HTTP/API call to fetch data → same string format into self.database_content
```
**What to do:** Replace the `open()` with your API client call. Return the same text format (records separated by double newlines). The rest of the system doesn't care where the text came from.

#### 2. `V2/backend/agents/orchestrator.py` — `_handle_text_db_search()` (line ~518)
```
CURRENT:  open(db_path, "r") → reads file, splits by \n\n, matches terms
CHANGE:   API call with query parameter → same matching logic
```
**What to do:** Replace `open()` with API call. OR better — if your API can search server-side, replace the entire method with an API query and return `{"result": "matched records"}`.

#### 3. `V2/backend/tools/agent_specific/sigint/correlation_tool.py` — `execute()` (line ~75)
```
CURRENT:  open(self.db_path, "r") → reads correlation_db.txt
CHANGE:   API call to SIGINT correlation service
```
**What to do:** Replace file read with API call. The two-stage correlation logic stays — just change the data source.

#### 4. `V2/backend/tools/shared/voter_db_tool.py` — `__init__()` (line ~44)
```
CURRENT:  csv.DictReader(open(self.csv_path)) → loads voter.csv into memory
CHANGE:   API call to voter registration database
```
**What to do:** Replace CSV read with database query. Return same dict format.

#### 5. `V2/backend/config.py` — Database paths
```
CURRENT:  TRAVEL_DB = os.path.join(DATA_DIR, "travel_db.txt") etc.
CHANGE:   TRAVEL_API_URL = os.getenv("TRAVEL_API_URL", "https://...") etc.
```
**What to do:** Replace file paths with API endpoints. Each agent gets its own URL.

### THE FILES THAT DON'T CHANGE:

| Category | Files | Why |
|----------|-------|-----|
| **Agent classes** (15) | travel_agent.py, sigint_agent.py, etc. | They only define role descriptions, never touch data |
| **Tool-calling engine** | tool_calling_engine.py | Routes tool calls, doesn't touch data |
| **Report synthesizers** (2) | report_synthesizer.py, targeting_report_synthesizer.py | Process results, not raw data |
| **Adapter tools** (3) | cdr_query.py, travel_query.py, fisa_query.py | Receive pre-loaded text as parameter, parse it |
| **Network tools** | contact_search.py, agent_query_tool.py | Use agent.database_content (already loaded) |
| **Event system** | event_bus.py | SSE streaming, no data access |
| **Storage** | target_store.py, results_store.py | SQLite for dedup/reports, not intelligence data |
| **Frontend** | index.html | UI only |
| **API server** | api_server.py | Routes HTTP requests, no data access |
| **Managers** | leo_manager.py, targeting_manager.py | Orchestration, not data access |

### CDR-SPECIFIC CHANGES FOR REAL API:

If your real CDR API accepts different parameters:

```python
# CURRENT: cdr_query.py takes raw text and parses it
tool.execute(data="CALL_LOG_001\nPhone: +964...", phone_filter="+964...")

# REAL API: You'd create a new tool or modify cdr_query.py
tool.execute(phone="+964-770-123-4567", date_from="2025-10-13", date_to="2026-04-13")
```

**Option A:** Modify `cdr_query.py` to call API directly (replaces text parsing)
**Option B:** Keep `cdr_query.py` as parser, change `base_agent.load_database()` to call API and return text format

**Option B is recommended** — it means cdr_query.py stays unchanged and works with both text files and API responses formatted as text.

### WORKFLOW CHANGES FOR REAL SIGINT:

The correlation workflow stays identical:
```
1. correlate_identifiers(phone) → calls correlation API instead of reading .txt
2. get_datetime(months_back=3) → calculates date range (no change needed)
3. search_own_database(query="all phones + IMEIs") → calls CDR API instead of reading .txt
```

Only the **data source** changes. The **workflow logic** is API-agnostic.

---

## ready_to_push_v2/ Transfer Files

| File | Lines | Contents |
|------|-------|----------|
| `01_FRONTEND.txt` | 2,108 | index.html |
| `02_AGENTS.txt` | 2,711 | base_agent.py, orchestrator.py, leo_manager.py, targeting_manager.py |
| `03_BACKEND_CORE.txt` | 1,636 | api_server.py, llm_provider.py, config.py |
| `04_TOOLS.txt` | 4,543 | tool_calling_engine.py, report_synthesizer.py, sub_agent_processor.py, targeting_report_synthesizer.py, event_bus.py, agent_query_tool.py, target_store.py, datetime_tool.py, correlation_tool.py, text_file_connector.py, json_connector.py, tool_definitions.py |
| `05_DATA.txt` | 174 | correlation_db.txt |
| **Total** | **11,172** | |

### How to use on air-gapped system:
1. Copy `ready_to_push_v2/` folder
2. Open each .txt file
3. Find `FILE:` header → copy code below it → paste into `DESTINATION:` path
4. Copy `correlation_db.txt` to `V2/backend/data/`
5. Restart: `python main.py`
