# LEO Agentic AI Platform V2

Multi-agent intelligence analysis platform with 15 specialized agents, tool-calling engine, concurrent execution, and three workflow types (LEO Cards, Targeting, Trace).

---

## Architecture Overview

```
Frontend (index.html)
    |
    v
API Server (api_server.py) ── FastAPI, SSE streaming
    |
    v
Orchestrator (orchestrator.py) ── 15 agents, 10 tools, concurrent execution
    |
    ├── Tool-Calling Engine ── LLM decides which tools to call
    |       |
    |       ├── search_own_database ── Auto-expands names + auto-correlates phones
    |       ├── query_agent ── Cross-agent database queries
    |       ├── expand_name_variations ── Arabic/English transliterations
    |       ├── correlate_identifiers ── Phone/IMEI/IMSI two-stage correlation
    |       ├── search_voter_database ── Iraqi voter registration
    |       ├── search_text_database ── Cross-agent text search
    |       ├── extract_entities ── Regex entity extraction
    |       ├── analyze_with_llm ── Deep analysis
    |       ├── get_datetime ── Current date + time calculations
    |       └── translate ── External translation/OCR API
    |
    ├── Report Synthesizer ── Intelligence reports
    ├── Targeting Report Synthesizer ── Targeting assessments
    ├── Trace Report Synthesizer ── Search-hit trace reports
    └── Target Store (SQLite) ── Dedup, versioned reports, audit trail
```

### How a query flows:

1. User submits target identifiers (name, phone, email, etc.)
2. Orchestrator runs 15 agents concurrently (5 threads max)
3. Each agent gets a tool-calling engine with 10 tools
4. LLM autonomously decides which tools to call (search, cross-reference, etc.)
5. **Mandatory**: Names auto-expanded (18+ variations), phones auto-correlated (IMEI/IMSI chains)
6. Results collected, deduplicated, stored in SQLite
7. Report synthesized based on workflow type (LEO/Targeting/Trace)
8. Results streamed to frontend via SSE events

---

## Directory Structure

```
V2/
├── frontend/
│   └── index.html              # Complete single-page UI (HTML + CSS + JS)
│
├── backend/
│   ├── main.py                 # Entry point: uvicorn server on port 8000
│   ├── api_server.py           # FastAPI routes, SSE endpoints, all CRUD
│   ├── config.py               # All configuration (API keys, DB paths, limits)
│   ├── llm_provider.py         # Multi-provider LLM with retry + failover
│   ├── create_voter_db.py      # Script to create voter SQLite from CSV
│   │
│   ├── agents/                 # All agent classes + managers
│   │   ├── base_agent.py       # Base class: tool-calling, thread-safe DB load
│   │   ├── orchestrator.py     # Central hub: 15 agents, 10 tools, pipeline
│   │   ├── leo_manager.py      # LEO Card CRUD + execution
│   │   ├── targeting_manager.py# Targeting + Trace workflow CRUD + execution
│   │   ├── chat_manager.py     # Chat session management
│   │   ├── unified_agent.py    # Cross-database unified search
│   │   ├── sna_agent.py        # Social Network Analysis
│   │   ├── travel_agent.py     # Travel/flight records
│   │   ├── sigint_agent.py     # Signals intelligence (CDR, calls)
│   │   ├── meta_data_agent.py  # IP addresses, device metadata
│   │   ├── osint_agent.py      # Open source intelligence
│   │   ├── intel_reports_agent.py # Intelligence reports
│   │   ├── fisa_agent.py       # FISA surveillance orders
│   │   ├── cne_agent.py        # Digital forensics, emails
│   │   ├── access_agent.py     # Information access, clearances
│   │   ├── accessibility_agent.py # Physical accessibility, routines
│   │   ├── motivation_agent.py # Motivations, vulnerabilities
│   │   ├── suitability_agent.py# Recruitment suitability
│   │   ├── security_agent.py   # Officer safety, OPSEC
│   │   ├── counter_intel_agent.py # Counter-intelligence risk
│   │   ├── geoint_agent.py     # Geospatial intelligence
│   │   └── pattern_of_life_agent.py # Daily routines, patterns
│   │
│   ├── tools/
│   │   ├── base_tool.py        # BaseTool class + ToolResult dataclass
│   │   ├── tool_definitions.py # Central schema registry for all tools
│   │   ├── tool_registry.py    # Dynamic tool discovery + registration
│   │   │
│   │   ├── shared/             # Tools available to ALL agents
│   │   │   ├── tool_calling_engine.py   # Core: LLM → parse XML → execute → loop
│   │   │   ├── agent_query_tool.py      # Cross-agent database queries
│   │   │   ├── name_variation_generator.py # Arabic/English name expansion
│   │   │   ├── datetime_tool.py         # Current date + time calculations
│   │   │   ├── translation_tool.py      # External translation/OCR API
│   │   │   ├── voter_db_tool.py         # Iraqi voter registration search
│   │   │   ├── contact_search.py        # Cross-DB contact search (0 LLM)
│   │   │   ├── generic_entity_extractor.py # Regex entity extraction
│   │   │   ├── large_data_processor.py  # Chunk large datasets
│   │   │   ├── sub_agent_processor.py   # Concurrent sub-agent workers
│   │   │   ├── report_synthesizer.py    # LEO intelligence reports
│   │   │   ├── targeting_report_synthesizer.py # Targeting assessment reports
│   │   │   ├── trace_report_synthesizer.py     # Trace search-hit reports
│   │   │   ├── event_bus.py             # SSE event streaming (thread-safe)
│   │   │   ├── results_store.py         # SQLite: sub-agent results
│   │   │   └── target_store.py          # SQLite: targets, records, reports
│   │   │
│   │   ├── agent_specific/     # Tools for specific agents only
│   │   │   ├── sigint/
│   │   │   │   ├── cdr_query.py         # Parse CDR text → structured records
│   │   │   │   └── correlation_tool.py  # Phone/IMEI/IMSI correlation
│   │   │   ├── travel/
│   │   │   │   └── travel_query.py      # Parse travel records → trips
│   │   │   ├── fisa/
│   │   │   │   └── fisa_query.py        # Parse FISA orders
│   │   │   └── sna/
│   │   │       ├── build_network.py     # Build social network graph
│   │   │       └── analyze_network.py   # Analyze graph (clusters, risk)
│   │   │
│   │   ├── database_connectors/ # Generic DB access
│   │   │   ├── text_file_connector.py   # Search text file databases
│   │   │   └── json_connector.py        # Search JSON files
│   │   │
│   │   └── api_integrations/    # External API wrappers
│   │       ├── osint_tools.py           # Social media, WHOIS
│   │       └── reverse_lookup.py        # Phone, email, breach lookups
│   │
│   └── data/                   # All databases + persistent storage
│       ├── travel_db.txt       # Flight manifests, border crossings
│       ├── sigint_db.txt       # CDR, SMS, voice intercepts
│       ├── meta_data_db.txt    # IP addresses, device fingerprints
│       ├── osint_db.txt        # Social media, public records
│       ├── intel_reports_db.txt# HUMINT reports, case files
│       ├── fisa_db.txt         # FISA court orders, surveillance
│       ├── cne_db.txt          # Device extractions, forensics
│       ├── access_db.txt       # Organizational access, clearances
│       ├── accessibility_db.txt# Daily routines, venue assessments
│       ├── motivation_db.txt   # Financial profiles, MICE analysis
│       ├── suitability_db.txt  # Recruitment assessments
│       ├── security_db.txt     # Officer safety, counter-surveillance
│       ├── counter_intel_db.txt# CI assessments, double agent indicators
│       ├── geoint_db.txt       # GPS coordinates, satellite imagery
│       ├── pattern_of_life_db.txt # Hour-by-hour routines
│       ├── correlation_db.txt  # Phone/IMEI/IMSI associations
│       ├── voter.csv           # Iraqi voter registration (30 records)
│       ├── leos.json           # Saved LEO card configurations
│       ├── targeting_workflows.json # Saved targeting workflows
│       ├── trace_workflows.json    # Saved trace workflows
│       ├── target_store.db     # SQLite: targets, records, reports
│       ├── results_store.db    # SQLite: sub-agent processing results
│       └── voter_registration.db # SQLite: voter data (from CSV)
```

---

## Core Scripts — What Each Does

### Entry Points

| Script | Purpose |
|--------|---------|
| `main.py` | Starts uvicorn server on `0.0.0.0:8000` with auto-reload |
| `api_server.py` | All HTTP endpoints, initializes orchestrator + managers |

### `api_server.py` — All API Endpoints

**Health:**
- `GET /` — Platform status, agent count, version

**Target Card / LEO:**
- `POST /target-card` — Create target card (all 15 agents)
- `POST /leo/create` — Create LEO card (select agents)
- `GET /leo/list` — List all LEOs
- `POST /leo/run/{id}` — Execute LEO
- `POST /leo/rerun/{id}` — Re-run specific agents only
- `POST /leo/schedule/{id}` — Schedule periodic re-runs
- `DELETE /leo/schedule/{id}` — Cancel schedule
- `PUT /leo/update/{id}` — Update LEO config
- `GET /leo/{id}/detail` — LEO details
- `GET /leo/{id}/results` — LEO results
- `DELETE /leo/delete/{id}` — Delete LEO

**Targeting Workflow:**
- `POST /targeting/create` — Create targeting workflow
- `GET /targeting/list` — List all targeting workflows
- `POST /targeting/run/{id}` — Execute targeting workflow
- `POST /targeting/rerun/{id}` — Re-run specific agents
- `POST /targeting/schedule/{id}` — Schedule periodic re-runs
- `PUT /targeting/update/{id}` — Update workflow
- `GET /targeting/{id}/detail` — Workflow details
- `GET /targeting/{id}/results` — Workflow results
- `DELETE /targeting/{id}` — Delete workflow

**Trace Workflow:**
- `POST /trace/create` — Create trace workflow (with agent selection)
- `GET /trace/list` — List all trace workflows
- `POST /trace/run/{id}` — Execute trace workflow
- `GET /trace/{id}/results` — Trace results
- `DELETE /trace/{id}` — Delete trace

**Chat:**
- `POST /chat/start` — Start chat session with any agent
- `POST /chat/message` — Send message in chat session

**SSE Events:**
- `GET /events/{run_id}` — Server-Sent Events stream for live pipeline progress
- `GET /events/{run_id}/history` — Get historical events

**Targets:**
- `GET /targets` — List all targets with stats
- `GET /targets/{id}` — Target detail with records
- `GET /targets/{id}/records` — All records for target

**Utilities:**
- `POST /single-agent` — Run a single agent directly
- `POST /agentic-search` — Run agentic search on one agent
- `GET /metrics/llm` — LLM usage metrics
- `GET /tools` — List all registered tools

### `config.py` — Configuration

```python
# Air-gapped LLM endpoint
LLM_BASE_URL = "https://internal-llm.mil/v1"  # OpenAI-compatible
LLM_API_KEY = "your-key"
LLM_MODEL = "gpt-4o"
LLM_PROVIDER = "openai"  # Schema type

# Multi-provider fallback (non-air-gapped)
OPENAI_API_KEY = "..."
ANTHROPIC_API_KEY = "..."

# Translation API (external platform)
TRANSLATION_API_URL = "https://translate-api.example.com"
TRANSLATION_API_KEY = "..."

# Tool-calling limits
TOOL_CALLING_MAX_ITERATIONS = 10  # Max LLM calls per agent
TOOL_CALLING_MAX_MISTAKES = 3    # Max "no tool used" before abort
```

### `llm_provider.py` — LLM Abstraction

- Supports: OpenAI, Anthropic, Google, Local (OpenAI-compatible)
- **Retry**: 3 retries with exponential backoff (2s → 4s → 8s)
- **Failover**: Tries all configured providers in order
- **Raises `LLMError`**: Never returns error strings as content
- Rate-limit detection: auto-retries on 429, timeout, 5xx

---

## Agent System

### `orchestrator.py` — Central Hub

The orchestrator:
1. Initializes all 15 agents with their database paths
2. Creates a `ToolCallingEngine` for each agent with 10 registered tools
3. Manages the 5-phase pipeline (agent execution → preprocessing → contact search → SNA → synthesis)
4. Runs agents concurrently via `ThreadPoolExecutor(max_workers=5)`

**10 Registered Tools (available to every agent):**

| # | Tool | What it does | Mandatory? |
|---|------|-------------|-----------|
| 1 | `search_own_database` | Search the agent's own DB | Auto-expands names + correlates phones |
| 2 | `query_agent` | Query another agent's DB | Self-query redirected to own DB |
| 3 | `expand_name_variations` | Generate 18+ Arabic/English name variations | Auto-runs inside search |
| 4 | `correlate_identifiers` | Two-stage Phone→IMEI/IMSI→more phones | Auto-runs inside search |
| 5 | `search_voter_database` | Search Iraqi voter registration | |
| 6 | `search_text_database` | Search any agent's DB by name | Auto-expands inside |
| 7 | `extract_entities` | Extract phones, emails, IPs from text | |
| 8 | `analyze_with_llm` | Deep analytical reasoning | |
| 9 | `get_datetime` | Current date + time range calculations | |
| 10 | `translate` | External translation/OCR API | |

**Mandatory Pre-Search Enforcement:**
- Every `search_own_database` call auto-runs `_auto_expand_query()`:
  - Detects phone numbers in query → auto-runs `correlate_identifiers` (iterative IMEI/IMSI chain)
  - Detects names in query → auto-runs `expand_name_variations` (18+ transliterations)
  - Returns combined search terms (all phones + IMEIs + IMSIs + name variations)
- The LLM cannot skip these steps — they're enforced in handler code

### `base_agent.py` — Base Class

Every agent inherits from `BaseAgent`:
- `search()` — Main entry point, uses tool-calling engine
- `chat()` — Interactive chat with conversation history
- `load_database()` — Reads text file database
- `ensure_database_loaded()` — Thread-safe lazy load with double-checked locking

### `tool_calling_engine.py` — The Core Loop

QCoder-style autonomous tool execution:
1. Send system prompt + tool definitions to LLM
2. LLM responds with XML tool calls: `<tool_name><param>value</param></tool_name>`
3. Engine parses XML, executes tool handler, gets result
4. Feeds result back to LLM as next message
5. Loops until `<attempt_completion>` or max iterations

**Features:**
- Sub-agent chunking: Large results (>4000 chars) split into chunks, each processed by sub-agent LLM
- Executive summary: Auto-generated summary prepended to large results
- No-data early exit: After 2 consecutive "no records found" searches, forces completion
- SSE event emission: Every tool call and LLM call emits events for live frontend display

### 15 Database Agents

Each agent has a role description, a database path, and uses the tool-calling engine:

| Agent | Database | Searches For |
|-------|----------|-------------|
| `travel` | travel_db.txt | Flight records, border crossings, co-travelers |
| `sigint` | sigint_db.txt | CDR, SMS, voice intercepts, cell towers |
| `meta` | meta_data_db.txt | IP addresses, device fingerprints, WiFi |
| `osint` | osint_db.txt | Social media, public records, WHOIS |
| `intel_reports` | intel_reports_db.txt | HUMINT reports, case files |
| `fisa` | fisa_db.txt | FISA court orders, surveillance logs |
| `cne` | cne_db.txt | Device extractions, emails, chat logs |
| `access` | access_db.txt | Clearances, organizational positions |
| `accessibility` | accessibility_db.txt | Daily routines, venue assessments |
| `motivation` | motivation_db.txt | Financial profiles, MICE analysis |
| `suitability` | suitability_db.txt | Recruitment assessments |
| `security` | security_db.txt | Officer safety, counter-surveillance |
| `counter_intel` | counter_intel_db.txt | CI assessments, loyalty concerns |
| `geoint` | geoint_db.txt | GPS coordinates, satellite imagery |
| `pattern_of_life` | pattern_of_life_db.txt | Hour-by-hour routines, patterns |

Plus special agents:
- `sna` — Social Network Analysis (builds graph from all agent results, no own DB)
- `unified` — Cross-database search (searches all DBs simultaneously)

---

## Three Workflow Types

### 1. LEO Card (Law Enforcement Order)
- **User selects which agents** to run (any subset of 15)
- Produces an intelligence report
- Can be scheduled for periodic re-runs
- Supports selective re-run (re-run only specific agents)

### 2. Targeting Workflow
- **Runs ALL 15 agents** automatically
- Produces a structured targeting report with sections:
  - Summary, Access, Accessibility, Motivations, Suitability, Pattern of Life, Security/CI
- Designed for full target assessment

### 3. Trace Workflow
- **User selects which agents** to run
- Produces a search-hit trace report with sections:
  - Summary, Name Search Results, Phone Number Search Results, Other Identifiers
- No assessments or conclusions — just organized search hits
- Shows WHERE a target appeared across databases

---

## Tools — Detailed Reference

### `correlation_tool.py` — SIGINT Correlation
- **Input**: Phone number
- **Output**: All linked phones, IMEIs, IMSIs
- **Process**: Iterative expansion (up to 5 passes):
  - Pass 1: Phone → find IMEI/IMSI from correlation_db.txt
  - Pass 2: Use IMEI/IMSI → find MORE phones (SIM swaps, device sharing)
  - Pass 3+: Feed new phones back → find even more linked devices
  - Stops when no new identifiers discovered (convergence)
- **Use case**: Reveals hidden phones, SIM swaps, shared devices

### `datetime_tool.py` — Date/Time for Air-Gapped Systems
- **Operations**: `now`, `range` (default by data type), `subtract` (custom)
- **Default ranges**: CDR=1yr, intel_reports=10yr, FISA=5yr, travel=3yr
- **Use case**: LLM has no date knowledge in air-gapped environments

### `translation_tool.py` — External Translation API
- **Operations**: `detect`, `translate`, `ocr`, `verify`
- **Verify**: Compares LLM translation vs API translation with word overlap scoring
- **Use case**: Large text translation, OCR from documents, translation verification

### `name_variation_generator.py` — Arabic Name Expansion
- Generates all English transliterations of Arabic names
- Handles: Muhammad/Mohammed/Mohammad, Al-/El-, Hassan/Hasan/Hasen, etc.
- Returns 18+ variations per name
- Used automatically inside every search (mandatory, enforced in code)

### `sub_agent_processor.py` — Concurrent Workers
- Splits large datasets into batches (2 records per worker)
- Spawns up to 50 concurrent asyncio workers
- Each worker gets parent agent's role description (domain expertise)
- Results persisted to SQLite, deduplicated by MD5 hash

### `event_bus.py` — SSE Streaming
- Thread-safe event emission with `threading.Lock`
- Event types: `pipeline_started`, `agent_started`, `agent_complete`, `tool_called`, `tool_result`, `llm_call_started`, `llm_call_complete`, `synthesis_started`, `pipeline_complete`
- Memory-bounded: max 5000 events per run, max 50 completed runs kept
- History replay for late-connecting SSE clients

### `target_store.py` — Persistent Storage
- SQLite with WAL mode for concurrent access
- Thread-safe writes with `_write_lock`
- **Deduplication**: Content hash (SHA-256) prevents duplicate records
- **Tombstones**: User-deleted records never re-imported
- **Versioned reports**: Each synthesis creates a new version
- **Audit trail**: Every run tracked with stats (new/duplicate/tombstoned)

---

## Frontend — `index.html`

Single-page application with these panels:
- **Dashboard** — Overview, system status
- **Target Card / LEO** — Create LEO cards, select agents, run, view results
- **Targeting Workflow** — Create targeting workflows, run all agents, structured reports
- **Trace Workflow** — Create trace workflows, select agents, search-hit reports
- **Targets** — Browse all targets, view records, manage tombstones
- **Chat** — Interactive chat with any agent
- **Settings** — API configuration

**UI Features:**
- Floating progress panel (minimizable, shows SSE events live)
- Mini indicator pill when panel closed but pipeline running
- Per-agent re-run buttons with status indicators (green/yellow/red)
- Schedule controls (6h/12h/24h/3d/weekly)
- Collapsible report sections with caret indicators
- Dark mode theme

---

## Database Format

Each text database uses double-newline separated records:

```
RECORD_ID_001
Field: Value
Field: Value
Notes: Free text

RECORD_ID_002
Field: Value
...
```

### Correlation Database Format (`correlation_db.txt`):
```
CORR_001
MSISDN: +964-770-555-1234
IMEI: 353456789012345
IMSI: 310260000000001
Date: 2024-01-15
Event: Device registration
Location: BGW-TOWER-003, Baghdad
Notes: Primary device for target. Samsung Galaxy S23.
```

### CDR Format (`sigint_db.txt`):
```
CALL_LOG_001
Phone: +1-555-0123 (John Smith)
Called: +1-555-0124 (Maria Garcia)
Date: 2024-03-14
Time: 14:30 UTC
Duration: 5 min
Type: Voice Call
Cell Tower: NYC-TOWER-0815, Manhattan
IMSI: 310260000000001
Notes: Pre-travel coordination call
```

---

## Setup & Running

### Requirements
```
pip install fastapi uvicorn openai anthropic python-dotenv requests
```

### Environment Variables (`.env`)
```
LLM_BASE_URL=https://your-llm-endpoint/v1
LLM_API_KEY=your-key
LLM_MODEL=gpt-4o
LLM_PROVIDER=openai

# Optional: Translation API
TRANSLATION_API_URL=https://translate-api.example.com
TRANSLATION_API_KEY=your-key
```

### Run
```bash
cd V2/backend
python main.py
# Server starts on http://0.0.0.0:8000
# Open V2/frontend/index.html in browser
```

---

## Adapter Pattern — Swapping to Real APIs

Only 5 files change when moving from text files to real databases/APIs:

| File | What Changes |
|------|-------------|
| `base_agent.py` | `load_database()` — file read → API call |
| `orchestrator.py` | `_handle_text_db_search()` — file read → API query |
| `correlation_tool.py` | `execute()` — file read → SIGINT correlation API |
| `voter_db_tool.py` | `__init__()` — CSV read → database query |
| `config.py` | File paths → API URLs |

Everything else stays unchanged — adapter tools (cdr_query, travel_query, fisa_query) receive pre-loaded text and parse it, regardless of source.

---

## Thread Safety

| Component | Protection |
|-----------|-----------|
| `target_store.py` | `_write_lock` on all write operations |
| `event_bus.py` | `threading.Lock` on emit/subscribe/history |
| `leo_manager.py` | `_save_lock` on JSON file writes |
| `targeting_manager.py` | `_save_lock` on JSON file writes |
| `base_agent.py` | `_db_load_lock` for lazy database loading |
| `agent_query_tool.py` | `_querying_lock` for recursion guard |
| `llm_provider.py` | Raises `LLMError` instead of returning error-as-content |
| `api_server.py` | `_store_pipeline_result()` with TTL cleanup (6h, max 100) |

---

## Developer Guide — How to Add / Modify

### How to Add a New Tool

A tool is a function the LLM can call during its search loop. There are 4 files to touch:

**Step 1: Create the tool class** in `tools/shared/your_tool.py` (or `tools/agent_specific/{agent}/`):

```python
from tools.base_tool import BaseTool, ToolResult

class YourTool(BaseTool):
    def __init__(self):
        super().__init__(
            name="your_tool_name",          # Must be unique, lowercase, underscores
            description="What this tool does",
            category="utility",
            version="1.0.0",
        )

    def get_parameter_schema(self):
        return {
            "required": ["param1"],
            "properties": {
                "param1": {"type": "string", "description": "What param1 is"},
                "param2": {"type": "string", "default": "", "description": "Optional"},
            },
        }

    def execute(self, param1: str = "", param2: str = "", **kwargs) -> ToolResult:
        # Your logic here
        # IMPORTANT: All params come as strings from XML parsing (even numbers)
        # Always handle str→int conversion if needed
        return ToolResult(success=True, data={"result": "your output text"})
```

**Step 2: Add the schema** to `tools/tool_definitions.py`:

```python
"your_tool_name": {
    "name": "your_tool_name",
    "description": "What this tool does (shown to LLM)",
    "parameters": [
        {"name": "param1", "type": "string", "required": True,
         "description": "What param1 is"},
        {"name": "param2", "type": "string", "required": False,
         "description": "Optional param"},
    ],
    "category": "utility",
},
```

**Step 3: Register in orchestrator** (`agents/orchestrator.py` in `_init_tool_calling_engines()`):

```python
# Add the ToolDefinition object (near the other tool definitions):
your_tool_def = ToolDefinition(
    name="your_tool_name",
    description="What this tool does",
    parameters=[
        {"name": "param1", "required": True, "description": "What param1 is"},
        {"name": "param2", "required": False, "description": "Optional"},
    ],
    handler=self._handle_your_tool,
)

# Register it in the engine loop (where other tools are registered):
engine.register_tool(your_tool_def)
```

**Step 4: Add the handler method** in `orchestrator.py`:

```python
def _handle_your_tool(self, param1: str = "", param2: str = "") -> Dict:
    """Handler for your_tool_name tool."""
    self._tool_log("your_tool", f"Running with param1={param1}")
    from tools.shared.your_tool import YourTool
    tool = YourTool()
    result = tool.execute(param1=param1, param2=param2)
    if result.success:
        return {"result": result.data.get("result", "")}
    return {"error": result.error}
```

**Optional Step 5: Add a guideline** in `tool_calling_engine.py` in the `get_tools_prompt()` method under `# Tool Use Guidelines` so the LLM knows when to use your tool.

### How to Add a New Agent

**Step 1: Create agent file** `agents/your_agent.py`:

```python
from agents.base_agent import BaseAgent

class YourAgent(BaseAgent):
    def __init__(self, db_path: str, llm=None):
        super().__init__(
            name="Your Agent Name",
            db_path=db_path,
            role_description="""You are a specialist in [domain].
            Your database contains [type of records].
            Search for [what to look for].""",
            llm=llm,
            agent_key="your_agent",
        )
```

That's it for the agent class. The tool-calling engine, tools, and search logic are all inherited from `BaseAgent`.

**Step 2: Add database path** to `config.py`:
```python
YOUR_AGENT_DB = os.path.join(DATA_DIR, "your_agent_db.txt")
```

**Step 3: Register in orchestrator** (`_init_agents()`):
```python
from .your_agent import YourAgent
# In _init_agents():
"your_agent": YourAgent(Config.YOUR_AGENT_DB, self.llm),
```

**Step 4: Add to agent lists** in:
- `orchestrator.py`: Add `"your_agent"` to `engine_agents` list (gets a tool-calling engine)
- `targeting_manager.py`: Add `"your_agent"` to `ALL_AGENTS` list
- `api_server.py`: Add `"your_agent"` to `VALID_AGENT_KEYS` set

**Step 5: Create the database file** `data/your_agent_db.txt` with records separated by double newlines.

**Step 6: Add to frontend** `index.html`:
- Add to `AGENTS` dict at the top of the script section with icon + name + description

### How to Add a New Database

Text file databases are the simplest:

1. Create `data/your_db.txt` with records separated by `\n\n`
2. Each record should have a unique ID on the first line (e.g., `RECORD_001`)
3. Fields as `Key: Value` pairs, one per line
4. Add path to `config.py`: `YOUR_DB = os.path.join(DATA_DIR, "your_db.txt")`

The `search_own_database` handler does flat OR matching across all terms — any record containing any search term is returned.

### How to Add a New Workflow Type

The platform has 3 workflows (LEO, Targeting, Trace). To add a 4th:

**Step 1: Create report synthesizer** `tools/shared/your_report_synthesizer.py`:
- Must have a `synthesize_your_report()` method
- Takes `target_identifiers`, `agent_results_map`, `preprocessed_data`, etc.
- Returns `{"report_id": str, "final_report": str, "sections": dict, "memory": dict}`

**Step 2: Add workflow methods** to `targeting_manager.py` (or create a new manager):
- `create_your_workflow()`, `get_your_workflow()`, `get_all_your_workflows()`, `delete_your_workflow()`
- `run_your_workflow()` — runs agents, calls your synthesizer
- Separate JSON file for storage (e.g., `data/your_workflows.json`)

**Step 3: Add API endpoints** to `api_server.py`:
- `POST /your-workflow/create`
- `GET /your-workflow/list`
- `POST /your-workflow/run/{id}`
- `GET /your-workflow/{id}/results`
- `DELETE /your-workflow/{id}`

**Step 4: Add frontend tab** in `index.html`:
- Nav item: `<div class="nav-item" onclick="switchPanel('your-workflow')">...</div>`
- Panel: `<div id="your-workflow-panel" class="content-panel">...</div>`
- JavaScript: create/list/run/view functions
- Update `switchPanel()` to auto-refresh on tab switch

### How to Add a New API Endpoint

1. Add Pydantic request model (if POST/PUT):
```python
class YourRequest(BaseModel):
    field1: str
    field2: Optional[str] = None
```

2. Add the endpoint:
```python
@app.post("/your-endpoint")
async def your_endpoint(request: YourRequest):
    # Your logic
    return {"status": "success", "data": result}
```

3. For background execution with SSE:
```python
@app.post("/your-endpoint/{id}")
async def your_endpoint(id: str, background: bool = True):
    if background:
        run_id = target_store.start_run(...)
        def _run_in_bg():
            try:
                result = your_manager.run(id, event_bus=event_bus, run_id=run_id)
            except Exception as e:
                event_bus.emit(PipelineEvent(event_type="pipeline_error", ...))
        thread = threading.Thread(target=_run_in_bg, daemon=True)
        thread.start()
        return {"status": "started", "run_id": run_id}
```

### How to Swap Text Files for Real APIs

Only 5 files need to change. See "Adapter Pattern" section above.

The key principle: `agent.database_content` is a string. Change how that string is loaded (file read → API call → same string format), and everything downstream works.

For each agent's `load_database()`:
```python
# BEFORE (text file):
with open(self.db_path, "r") as f:
    return f.read()

# AFTER (API):
response = requests.get(f"{API_URL}/data/{self.agent_key}", headers=auth_headers)
return response.text  # Same format: records separated by \n\n
```

### How to Add SSE Events

Events flow: Tool handler → EventBus → SSE endpoint → Frontend

1. In your handler/pipeline code:
```python
event_bus.emit(PipelineEvent(
    event_type="your_event_type",
    run_id=run_id,
    agent_key="agent_name",
    message="Human-readable description",
    data={"key": "value"},
))
```

2. Add icon in frontend `EVENT_ICONS`:
```javascript
const EVENT_ICONS = {
    // existing...
    your_event_type: '🔔',
};
```

### How to Modify Report Format

Each synthesizer has a `_generate_section()` or similar method that calls the LLM with:
- System prompt (what role the LLM plays for this section)
- Agent data (filtered by section)
- Target description

To change what sections appear in a report:
1. Edit the synthesizer's `SECTION_AGENT_MAP` (which agents feed which sections)
2. Edit the main `synthesize_*_report()` method (which sections to generate)
3. Edit the `_build_final_report()` method (how sections are assembled)
4. Update frontend rendering function for that report type

### How to Add Input Validation

For API endpoints:
```python
# In api_server.py, before processing:
if not request.field1 or not request.field1.strip():
    raise HTTPException(status_code=400, detail="field1 is required")

# For agent_keys validation:
invalid = [a for a in request.agent_keys if a not in VALID_AGENT_KEYS]
if invalid:
    raise HTTPException(status_code=400, detail=f"Invalid agents: {invalid}")
```

### How to Debug

1. **Backend logs**: All tool calls logged with `[TOOL:name]` prefix, engine iterations with `[ENGINE]`
2. **SSE events**: Every tool call and LLM call emits events visible in the floating panel
3. **Target Store**: Check `data/target_store.db` with any SQLite viewer for stored records, reports, runs
4. **Results Store**: Check `data/results_store.db` for sub-agent processing results
5. **LLM Metrics**: `GET /metrics/llm` shows total calls, success rate, latency, per-provider stats

### Performance Tuning

| Setting | Where | Default | Effect |
|---------|-------|---------|--------|
| `TOOL_CALLING_MAX_ITERATIONS` | config.py | 10 | Max LLM calls per agent search |
| `TOOL_CALLING_MAX_MISTAKES` | config.py | 3 | Max "no tool used" before abort |
| `ThreadPoolExecutor(max_workers=)` | orchestrator.py | 5 | Concurrent agents |
| `LARGE_RESULT_THRESHOLD` | tool_calling_engine.py | 4000 | Chars to trigger sub-agent chunking |
| `CHUNK_TARGET_SIZE` | tool_calling_engine.py | 3000 | Chars per sub-agent chunk |
| `SUB_AGENT_MAX_WORKERS` | config.py | 50 | Max concurrent sub-agent workers |
| `MAX_HISTORY_PER_RUN` | event_bus.py | 5000 | Max SSE events per pipeline run |
| `MAX_COMPLETED_RUNS` | event_bus.py | 50 | Max completed runs kept in memory |
| `_PIPELINE_RESULTS_MAX_AGE` | api_server.py | 6 hours | TTL for stored pipeline results |
| `_PIPELINE_RESULTS_MAX_COUNT` | api_server.py | 100 | Max pipeline results in memory |

### Error Handling Chain

```
LLM API call fails
  → llm_provider.py retries 3x with backoff (2s→4s→8s)
  → If all fail: raises LLMError (never returns error as content)
    → tool_calling_engine.py catches LLMError, returns {is_llm_error: True, result: ""}
      → base_agent.py propagates is_llm_error flag, clears result text
        → orchestrator.py detects error, stores empty result (not error text)
          → report_synthesizer.py _is_error_result() filters errors out
            → Final report has "Agent unavailable" instead of error strings
```

---

## Core Principles

This platform is a **data consolidation and intelligence retrieval system**, not a generative AI tool. The LLM's role is strictly limited:

### 1. Completeness
- Every tool is designed to return ALL matching records from a database, even if hundreds exist
- Sub-agent chunking processes large result sets without dropping any records
- Name expansion generates 18+ transliterations to ensure no records missed
- Phone correlation iterates until convergence to find ALL linked devices

### 2. Accuracy
- **No LLM fabrication**: All synthesizer prompts contain "ONLY use facts explicitly stated in the data"
- The LLM formats and organizes data — it does NOT generate, infer, or assume
- Every finding must cite a source record ID (e.g., `[Source: TRAVEL_008]`)
- Risk assessments removed — replaced with factual summaries of verified findings

### 3. Traceability
- **Audit trail**: Every pipeline run records which tools each agent called, with what parameters, and whether they succeeded
- **Raw data preserved**: Full agent results (raw tool output) stored alongside synthesized reports
- **Collapsible raw data**: Users can expand any agent's raw output in the results modal to see exactly what the tool returned
- **Tool call log**: Each agent's iterations, tool names, parameters, and success/failure visible in the audit trail
- **Versioned reports**: Every synthesis creates a new version — previous versions are never overwritten

### 4. No Data Leakage
- 49 dead code methods removed from 15 agents (all had `{self.database_content}` in LLM prompts)
- Agents ONLY access data through tool-calling engine — never see raw database content
- Search handlers enforce name expansion + phone correlation automatically (handler code, not LLM decision)
- Error messages never expose file paths

---

### Known Limitations

1. **Name variation generator**: O(M^N) complexity for N name parts with M variations each. Capped at 50 combinations.
2. **SQLite concurrent reads**: WAL mode handles most cases but heavy concurrent load may see occasional "database is locked" under extreme pressure.
3. **Translation tool**: Requires external API. Falls back with clear error if not configured.
4. **No authentication**: API endpoints have no auth. Add middleware for production deployment.
5. **LLM context window**: Very large agent results (>8000 chars) are chunked via sub-agents. Some cross-record context may be lost at chunk boundaries.
