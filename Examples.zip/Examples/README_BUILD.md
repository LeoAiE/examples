# How to Rebuild the AI Agent Platform from Text Files

You have **6 files** in this folder:

```
BUILD_PROJECT.py                       <-- the unpacker (~7 KB)
README_BUILD.md                        <-- this file
EXPORT_1_CORE.txt                      <-- 8 root files (entry points, config, README, ARCH)
EXPORT_2_AGENTS.txt                    <-- 22 agent files (orchestrator + 16 agents + managers)
EXPORT_3_TOOLS.txt                     <-- 42 tool files (shared + agent-specific + base)
EXPORT_4_PLANS_SCHEMAS_FRONTEND.txt    <-- 28 files (14 plans + 9 schemas + frontend + tests)
EXPORT_5_DATA.txt                      <-- 9 sample database files (real demo data)
```

That's everything — **109 files**, fully self-contained.

## To rebuild on any machine

1. **Move all 7 files** (the 5 `.txt` + `BUILD_PROJECT.py` + this README) to one folder. They must all be in the same folder.

2. **Open a terminal there** and run:
   ```bash
   python3 BUILD_PROJECT.py
   ```

   That's the entire setup. The script reads every `EXPORT_*.txt`, recreates the directory tree, and writes every file to its original location.

3. **Default destination is `./ai-agent-platform/`** in your current directory. To put it elsewhere:
   ```bash
   python3 BUILD_PROJECT.py --dest /path/to/your/folder
   ```

4. **Start the platform:**
   ```bash
   cd ai-agent-platform/V2/backend
   python3 -m venv venv && source venv/bin/activate
   pip install -r requirements.txt
   cp .env.example .env
   # Edit .env and add your LLM_API_KEY
   python3 main.py
   ```

   Then open `ai-agent-platform/V2/frontend/index.html` in a browser.

## What happens automatically

The build script:

- Recreates **109 files** in their original directory paths
- Creates the **7 empty assessment-agent databases** (access_db.txt, accessibility_db.txt, motivation_db.txt, suitability_db.txt, security_db.txt, counter_intel_db.txt, pattern_of_life_db.txt) — these have no demo data; they get populated as you use the platform
- Creates runtime placeholder directories (`data/dossiers/`, `__pycache__/`)
- Synthesizes `.env.example` with all the LLM provider settings you need to fill in
- Synthesizes `agents/__init__.py` if missing

You do **not** need to manually copy anything, create any folders, or run any other setup commands.

## What it preserves (do not edit)

The text files use unique markers to demarcate each file:

```
<<<<<<<<<< AAP_FILE_BEGIN >>>>>>>>>>
PATH: V2/backend/main.py
LINES: 5
BYTES: 162
<<<<<<<<<< AAP_FILE_CONTENT >>>>>>>>>>
<actual file content>
<<<<<<<<<< AAP_FILE_END >>>>>>>>>>
```

These markers are guaranteed not to appear in any source file. Editing the markers will break extraction. Editing **content** (between `_FILE_CONTENT` and `_FILE_END`) is fine — the build script writes whatever is there.

## What's in each export

| File | Contents | Size |
|------|----------|------|
| EXPORT_1_CORE.txt | `main.py`, `api_server.py`, `config.py`, `llm_provider.py`, `requirements.txt`, `README.md` (the full tool documentation), `ARCHITECTURE.md`, `.env.example` | ~233 KB |
| EXPORT_2_AGENTS.txt | `orchestrator.py`, `base_agent.py`, all 7 data agents, all 7 assessment agents, `sna_agent.py`, `unified_agent.py`, `leo_manager.py`, `targeting_manager.py`, `chat_manager.py` | ~162 KB |
| EXPORT_3_TOOLS.txt | `base_tool.py`, `tool_registry.py`, all 19 shared tools (incl. `living_dossier.py`, `dossier_pipeline.py`, `target_store.py`, etc.), all 23 agent-specific tools (SIGINT, Travel, FISA, CNE, OSINT, Intel, GEOINT, SNA), connectors, API integrations | ~646 KB |
| EXPORT_4_PLANS_SCHEMAS_FRONTEND.txt | 14 deterministic JSON plans, 9 database schemas, `frontend/index.html` (single-file UI), `test_e2e.py`, `test_reallife.py`, `create_voter_db.py`, `data/generate_databases.py` | ~531 KB |
| EXPORT_5_DATA.txt | 9 sample databases: `sigint_db.txt`, `travel_db.txt`, `osint_db.txt`, `intel_reports_db.txt`, `fisa_db.txt`, `cne_db.txt`, `geoint_db.txt`, `correlation_db.txt`, `voter.csv` — real demo data with cross-referenced identities (Mohammed Al-Husseini network) | ~646 KB |

**Total: ~2.2 MB across 5 text files.**

## Troubleshooting

- **"No EXPORT_*.txt files in <dir>"** — run from the same folder as the text files, or pass `--source /path/to/exports`.
- **"Destination already exists and is not empty"** — confirm overwrite, or use `--dest <new-path>`.
- **A specific file is missing after build** — check the relevant `EXPORT_N_*.txt` is actually there, then look at the script's per-file output to spot extraction failures.
- **`python3 main.py` errors on import** — make sure you ran from `V2/backend/` (the script uses absolute imports rooted there) and activated the venv.

## To regenerate the export files (only on the source machine)

The regen script is at `/tmp/regen_exports_v2.py` (or run from wherever you keep it). Re-run it whenever you change source files; it overwrites the 5 `EXPORT_*.txt` files in this directory with current content.

---

*Sample data identity:* the demo databases all reference an Iraqi target named Mohammed Ali Al-Husseini (`+964-770-555-1234`), his associate Tariq Al-Bayati (`+964-770-555-5678`), and a 6-person network. Use these in `TEST_PLAN.md` to validate every agent and workflow after rebuild.
