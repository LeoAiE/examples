# LEO Agentic AI Platform V2 — Complete Tool Bible

> **PURPOSE**: Dumb-proof documentation for the AI Agent Platform V2. Every script, every connection, every configuration. Step-by-step instructions for changing ANY tool, agent, prompt, or report — with exact file paths and exact locations.

---

## TABLE OF CONTENTS

1. [Quick Start](#1-quick-start)
2. [Architecture Overview](#2-architecture-overview)
3. [The Living Dossier Pipeline (Current Architecture)](#3-the-living-dossier-pipeline)
4. [Directory Structure](#4-directory-structure)
5. [Every Script Explained](#5-every-script-explained)
6. [Per-Agent Walkthrough (What To Change & Where)](#6-per-agent-walkthrough)
7. [Per-Tool Walkthrough (What To Change & Where)](#7-per-tool-walkthrough)
8. [Per-JSON Plan Walkthrough](#8-per-json-plan-walkthrough)
9. [How To Change Report Prompts](#9-how-to-change-report-prompts)
10. [How To Change Report Formatting](#10-how-to-change-report-formatting)
11. [API Endpoints Reference](#11-api-endpoints-reference)
12. [Configuration Reference](#12-configuration-reference)
13. [Dependency Map (If I Change X, What Breaks?)](#13-dependency-map)

---

## 1. QUICK START

```bash
cd V2/backend
pip install -r requirements.txt
python main.py
# Server: http://0.0.0.0:8000
# Frontend: open browser to http://localhost:8000
```

### Required `.env` File

```bash
# At least ONE LLM key required:
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=AIza...

# Optional overrides:
LLM_PROVIDER=openai          # openai | anthropic | google | local
LLM_MODEL=gpt-4o-mini        # Model name
LLM_BASE_URL=                 # Custom endpoint (for local/proxy)
LLM_API_KEY=                  # If using custom endpoint
```

### Verify

```bash
curl http://localhost:8000/          # Health check
curl http://localhost:8000/agents    # List all 15 agents
```

---

## 2. ARCHITECTURE OVERVIEW

```
+------------------------------------------------------------------+
|                       FRONTEND (index.html)                        |
|  Chat UI | Target Card | LEO | Targeting | Trace | Results        |
+------------------------------+-----------------------------------+
                               |
                          HTTP / SSE
                               |
+------------------------------v-----------------------------------+
|                  api_server.py (FastAPI, 60+ endpoints)           |
+--+--------+--------+--------+--------+--------+---------+--------+
   |        |        |        |        |        |         |
   v        v        v        v        v        v         v
+------+ +------+ +------+ +------+ +------+ +-------+ +------+
|Orch- | |LEO   | |Targ- | |Chat  | |Event | |Target | |Result|
|estr- | |Mana- | |eting | |Mana- | |Bus   | |Store  | |Store |
|ator  | |ger   | |Mana- | |ger   | |(SSE) | |(SQL)  | |(SQL) |
+--+---+ +--+---+ |ger   | +--+---+ +------+ +-------+ +------+
   |        |      +--+---+    |
   |        |         |        |
   v        v         v        v
+--+--------+---------+--------+---+
|       DossierPipeline            |
|  7 steps: INPUT→EXPAND→COLLECT→  |
|  ENRICH→COMPILE→ASSESS→FINAL    |
+--+-------------------------------+
   |
   v
+--+-------------------------------+
|         Living Dossier           |
|  Formatters, Sections, Summaries |
|  Assessments, Narrative, ExecSum |
+--+-------------------------------+
   |
   v
+--+-------------------------------+
|     14 Agents (+ SNA + Unified)  |
|  Each has: plan, tools, database |
+--+-------------------------------+
   |
   +---> Plan Executor (deterministic JSON steps)
   +---> Tool Calling Engine (autonomous LLM loop)
   +---> Sub-Agent Processor (parallel chunked workers)
   |
   v
+--+-------------------------------+
|           Tool Layer             |
|  Search tools, query tools,      |
|  analysis tools, utility tools   |
+--+-------------------------------+
   |
   v
+--+-------------------------------+
|        Data Layer                |
|  15 text DBs | voter.csv/SQLite  |
|  target_store.db | results.db    |
|  dossiers/ (file system)         |
+----------------------------------+
```

### Three Workflows

| Workflow | Agents Used | Output | Key Difference |
|----------|-------------|--------|----------------|
| **Targeting** | 7 data + 7 assessment + SNA | Full dossier + exec summary + narrative (11 sections from assessments) | Runs ALL 7 pipeline steps |
| **Trace** | 7 data agents only | Trace report (lighter) | Skips ASSESS step (step 6), narrative from data sources |
| **LEO** | 7 data agents only | Dossier + narrative (no assessments) | Skips ASSESS step, adds scheduling |

---

## 3. THE LIVING DOSSIER PIPELINE

### What Replaced What

The old architecture had:
- `report_synthesizer.py` (DELETED)
- `targeting_report_synthesizer.py` (DELETED)
- `agent_consolidator.py` (DELETED)
- `fact_extractor.py` (DELETED)
- `dossier_generator.py` (DELETED)
- `memory_engine.py` (DELETED)
- `large_data_processor.py` (DELETED)
- `generic_entity_extractor.py` (DELETED)

**ALL replaced by TWO files:**
- `tools/shared/living_dossier.py` (2024 lines) — Core engine
- `tools/shared/dossier_pipeline.py` (1160 lines) — Pipeline controller

### The 7 Steps

```
STEP 1: INPUT
    - Create dossier directory: data/dossiers/{target_id}/
    - Write identifiers/header.md (name, phone, passport, etc.)

STEP 2: EXPAND
    - name_variation_generator → 18+ Arabic/English transliterations
    - correlation_tool → find linked phones/IMEIs/IMSIs
    - Store expanded identifiers for all subsequent searches

STEP 3: COLLECT (parallel, 7 data agents)
    - For each data agent (sigint, travel, osint, intel_reports, fisa, cne, geoint):
      - agent.search(identifiers) via plan_executor
      - living_dossier.write_agent_section(results) → formats to markdown
      - living_dossier.summarize_section() → LLM summary (1-2K chars)
    - Writes: data/dossiers/{target_id}/sections/01_sigint.md ... 07_geoint.md

STEP 4: ENRICH (max 3 iterations)
    - contact_search → find new phone numbers in results
    - For each new identifier → search relevant agents again → append to sections
    - enrichment_tracker tracks iterations until convergence

STEP 5: COMPILE (zero LLM)
    - compile_cross_references() → Python regex across all sections
    - compile_contact_network() → phone extraction + name resolution
    - compile_voter_results() → voter DB lookup
    - compile_dossier() → concatenate all sections into versioned file
    - Writes: data/dossiers/{target_id}/sections/08_meta.md

STEP 6: ASSESS (7 assessment types — SKIPPED in trace/LEO)
    - For each assessment (access, accessibility, motivation, etc.):
      - Read compiled dossier
      - Chunk into 3K char segments
      - _is_pure_index_chunk() → skip table-of-contents chunks
      - Regex pre-scan with keywords → prioritize relevant chunks
      - For each relevant chunk: LLM scan for assessment-specific facts
      - Compile findings into assessment markdown
    - Writes: assess_access.md, assess_accessibility.md, etc.

STEP 7: FINAL
    - generate_executive_summary(dossier_text, identifiers) → 4000 tokens
    - generate_narrative_report(dossier_text, identifiers) → 11 sections × 2000 tokens
    - Store report in target_store
    - Stream final event via SSE
```

### Dossier Disk Structure

```
data/dossiers/{target_id}/
    identifiers/
        header.md              # Target identity (name, phone, passport)
    sections/
        01_sigint.md           # SIGINT formatted records + summary
        02_travel.md           # Travel formatted records + summary
        03_cne.md              # CNE formatted records + summary
        04_fisa.md             # FISA formatted records + summary
        05_osint.md            # OSINT formatted records + summary
        06_intel_reports.md    # Intel reports formatted + summary
        07_geoint.md           # GEOINT formatted records + summary
        08_meta.md             # Cross-references + contact network + voter
    assessments/               # (targeting workflow only)
        assess_access.md
        assess_accessibility.md
        assess_motivation.md
        assess_suitability.md
        assess_security.md
        assess_counter_intel.md
        assess_pattern_of_life.md
    dossier_v1.md              # First compiled version
    dossier_v2.md              # After enrichment
    ...
```

---

## 4. DIRECTORY STRUCTURE

```
V2/
├── frontend/
│   └── index.html              # Complete single-page UI (2694 lines)
│
├── backend/
│   ├── main.py                 # Entry point: uvicorn server
│   ├── api_server.py           # FastAPI routes, SSE, all CRUD (1640 lines)
│   ├── config.py               # All configuration (94 lines)
│   ├── llm_provider.py         # Multi-provider LLM with retry (324 lines)
│   │
│   ├── agents/
│   │   ├── orchestrator.py     # Central hub (1558 lines)
│   │   ├── base_agent.py       # Base class (615 lines)
│   │   ├── sigint_agent.py     # CDR/communications
│   │   ├── travel_agent.py     # Flight/border records
│   │   ├── osint_agent.py      # Open source intelligence
│   │   ├── intel_reports_agent.py # Intelligence reports
│   │   ├── fisa_agent.py       # FISA surveillance
│   │   ├── cne_agent.py        # Computer network exploitation
│   │   ├── geoint_agent.py     # Geospatial intelligence
│   │   ├── access_agent.py     # Assessment: access
│   │   ├── accessibility_agent.py # Assessment: accessibility
│   │   ├── motivation_agent.py # Assessment: motivation
│   │   ├── suitability_agent.py # Assessment: suitability
│   │   ├── security_agent.py   # Assessment: security
│   │   ├── counter_intel_agent.py # Assessment: counter-intel
│   │   ├── pattern_of_life_agent.py # Assessment: pattern of life
│   │   ├── sna_agent.py        # Social network analysis (167 lines)
│   │   ├── unified_agent.py    # Cross-database unified search
│   │   ├── leo_manager.py      # LEO workflow CRUD (215 lines)
│   │   ├── targeting_manager.py # Targeting workflow CRUD (379 lines)
│   │   └── chat_manager.py     # Chat session management (99 lines)
│   │
│   ├── tools/
│   │   ├── base_tool.py        # BaseTool abstract class
│   │   ├── tool_definitions.py # JSON schemas for LLM tool calling
│   │   ├── tool_registry.py    # Dynamic tool discovery
│   │   │
│   │   ├── shared/
│   │   │   ├── living_dossier.py         # Core dossier engine (2024 lines)
│   │   │   ├── dossier_pipeline.py       # 7-step pipeline (1160 lines)
│   │   │   ├── trace_report_synthesizer.py # Trace reports (523 lines)
│   │   │   ├── plan_executor.py          # JSON plan execution (1051 lines)
│   │   │   ├── tool_calling_engine.py    # LLM tool loop (844 lines)
│   │   │   ├── sub_agent_processor.py    # Parallel chunks (460 lines)
│   │   │   ├── target_store.py           # SQLite persistence (2195 lines)
│   │   │   ├── results_store.py          # Sub-agent results (427 lines)
│   │   │   ├── event_bus.py              # SSE streaming (133 lines)
│   │   │   ├── agent_query_tool.py       # Cross-agent queries (389 lines)
│   │   │   ├── contact_search.py         # Cross-DB phone lookup (258 lines)
│   │   │   ├── cross_target_linker.py    # Shared identifiers (801 lines)
│   │   │   ├── entity_resolver.py        # Duplicate detection (510 lines)
│   │   │   ├── enrichment_tracker.py     # Enrichment iterations (349 lines)
│   │   │   ├── identity_scorer.py        # Confidence scoring (372 lines)
│   │   │   ├── name_variation_generator.py # Arabic/English names (315 lines)
│   │   │   ├── voter_db_tool.py          # Voter registration (128 lines)
│   │   │   ├── translation_tool.py       # Translation (243 lines)
│   │   │   └── datetime_tool.py          # Date math (157 lines)
│   │   │
│   │   ├── agent_specific/
│   │   │   ├── base_agent_search_tool.py # Parent search class (205 lines)
│   │   │   ├── sigint/
│   │   │   │   ├── sigint_search_tool.py
│   │   │   │   ├── sigint_adapter.py
│   │   │   │   ├── cdr_query.py
│   │   │   │   └── correlation_tool.py
│   │   │   ├── travel/
│   │   │   │   ├── travel_search_tool.py
│   │   │   │   ├── travel_query.py
│   │   │   │   └── co_traveler_search.py
│   │   │   ├── fisa/
│   │   │   │   ├── fisa_search_tool.py
│   │   │   │   └── fisa_query.py
│   │   │   ├── cne/cne_search_tool.py
│   │   │   ├── geoint/geoint_search_tool.py
│   │   │   ├── osint/osint_search_tool.py
│   │   │   ├── intel_reports/intel_reports_search_tool.py
│   │   │   └── sna/
│   │   │       ├── build_network.py
│   │   │       └── analyze_network.py
│   │   │
│   │   ├── database_connectors/
│   │   │   ├── text_file_connector.py
│   │   │   └── json_connector.py
│   │   │
│   │   └── api_integrations/
│   │       ├── osint_tools.py
│   │       └── reverse_lookup.py
│   │
│   ├── plans/                  # 14 JSON execution plans
│   │   ├── sigint.json, travel.json, osint.json, intel_reports.json
│   │   ├── fisa.json, cne.json, geoint.json
│   │   ├── access.json, accessibility.json, motivation.json
│   │   ├── suitability.json, security.json
│   │   ├── counter_intel.json, pattern_of_life.json
│   │
│   ├── schemas/                # 9 database schema JSONs
│   │   ├── sigint_db.json, travel_db.json, osint_db.json
│   │   ├── intel_reports_db.json, fisa_db.json, cne_db.json
│   │   ├── geoint_db.json, correlation_db.json, voter_db.json
│   │
│   ├── data/                   # All databases
│   │   ├── sigint_db.txt, travel_db.txt, osint_db.txt
│   │   ├── intel_reports_db.txt, fisa_db.txt, cne_db.txt
│   │   ├── geoint_db.txt, correlation_db.txt
│   │   ├── access_db.txt, accessibility_db.txt, motivation_db.txt
│   │   ├── suitability_db.txt, security_db.txt, counter_intel_db.txt
│   │   ├── pattern_of_life_db.txt
│   │   ├── voter.csv, voter_registration.db
│   │   ├── leos.json, targeting_workflows.json, trace_workflows.json
│   │   ├── generate_databases.py
│   │   └── dossiers/           # Output dossier folders
│   │
│   ├── test_e2e.py             # End-to-end tests
│   └── test_reallife.py        # Real API tests
```

---

## 5. EVERY SCRIPT EXPLAINED

### Core (4 files)

| File | What It Does | Called By | Calls |
|------|-------------|-----------|-------|
| `main.py` | Starts uvicorn server | Shell | api_server |
| `api_server.py` | 60+ REST endpoints, CORS, SSE streaming | uvicorn | orchestrator, leo_manager, targeting_manager, chat_manager, event_bus, target_store |
| `config.py` | Loads .env, defines ALL paths and constants | EVERYONE | os, dotenv |
| `llm_provider.py` | Multi-provider LLM (OpenAI/Anthropic/Google/local), retry, thread-safe metrics | plan_executor, tool_calling_engine, sub_agent_processor, living_dossier, trace_report_synthesizer | openai, anthropic, google |

### Agents (20 files)

| File | What It Does | Called By |
|------|-------------|-----------|
| `orchestrator.py` | Registers 15 agents + tools + plans; runs pipelines | api_server |
| `base_agent.py` | Base class: search(), chat(), plan executor integration | All agent subclasses |
| `sigint_agent.py` | CDR/communications; overrides chat() for plan routing | orchestrator |
| `travel_agent.py` | Travel records | orchestrator |
| `osint_agent.py` | Open-source intel; custom search splitting | orchestrator |
| `intel_reports_agent.py` | Intelligence reports | orchestrator |
| `fisa_agent.py` | FISA surveillance records | orchestrator |
| `cne_agent.py` | Computer network exploitation | orchestrator |
| `geoint_agent.py` | Geospatial intelligence | orchestrator |
| `access_agent.py` | Assessment: access vectors | orchestrator |
| `accessibility_agent.py` | Assessment: physical accessibility | orchestrator |
| `motivation_agent.py` | Assessment: MICE framework | orchestrator |
| `suitability_agent.py` | Assessment: recruitment suitability | orchestrator |
| `security_agent.py` | Assessment: officer safety | orchestrator |
| `counter_intel_agent.py` | Assessment: CI risks | orchestrator |
| `pattern_of_life_agent.py` | Assessment: daily patterns | orchestrator |
| `sna_agent.py` | Social network analysis (no database) | orchestrator |
| `unified_agent.py` | Cross-database unified search | orchestrator |
| `leo_manager.py` | LEO workflow CRUD + pipeline execution | api_server |
| `targeting_manager.py` | Targeting/Trace workflow CRUD + pipeline execution | api_server |
| `chat_manager.py` | Multi-session chat with SQLite persistence | api_server |

### Shared Tools (19 files)

| File | What It Does | Called By |
|------|-------------|-----------|
| `living_dossier.py` | Core dossier engine: formatters, summaries, assessments, narrative, exec summary | dossier_pipeline |
| `dossier_pipeline.py` | 7-step pipeline controller | orchestrator, leo_manager, targeting_manager |
| `trace_report_synthesizer.py` | Trace workflow report with 5 narrative topics | dossier_pipeline |
| `plan_executor.py` | Deterministic JSON plan execution + sub-agent chunking | base_agent |
| `tool_calling_engine.py` | Autonomous LLM tool loop (max 10 iterations) | base_agent, chat_manager |
| `sub_agent_processor.py` | Concurrent chunked workers (up to 50 parallel) | plan_executor |
| `target_store.py` | SQLite: 20+ tables, thread-safe | orchestrator, api_server, dossier_pipeline |
| `results_store.py` | SQLite: sub-agent processing results | api_server, sub_agent_processor |
| `event_bus.py` | SSE event streaming | api_server, dossier_pipeline |
| `agent_query_tool.py` | Cross-agent query bridge + cache | plan_executor, tool_calling_engine |
| `contact_search.py` | Cross-DB phone contact discovery | dossier_pipeline |
| `cross_target_linker.py` | Shared identifiers across targets | living_dossier |
| `entity_resolver.py` | Jaccard similarity duplicate detection | orchestrator |
| `enrichment_tracker.py` | Enrichment iteration tracking (max 3) | dossier_pipeline |
| `identity_scorer.py` | Record confidence scoring (pure Python) | plan_executor |
| `name_variation_generator.py` | Arabic/English name expansion | plan_executor, tool_calling_engine |
| `voter_db_tool.py` | Iraq voter registration SQLite search | plan_executor, tool_calling_engine |
| `translation_tool.py` | Language detection + translation via LLM | plan_executor, tool_calling_engine |
| `datetime_tool.py` | Date math + data type ranges | plan_executor, tool_calling_engine |

---

## 6. PER-AGENT WALKTHROUGH (What To Change & Where)

### SIGINT AGENT — Complete Modification Guide

**I want to change what SIGINT searches for:**
1. Open `plans/sigint.json`
2. Find step with `"tool": "sigint_search"` (usually step_1)
3. Modify `params.query` — this is what gets searched in the database
4. To add a new search step, add a new object to the `steps` array

**I want to change how SIGINT results are analyzed:**
1. Open `plans/sigint.json`
2. Find steps with `"action": "analyze"` (usually step_3 and step_4)
3. Modify the `"prompt"` string — this is the LLM instruction

**I want to change how SIGINT data appears in the dossier:**
1. Open `tools/shared/living_dossier.py`
2. Search for `def _format_sigint` (around line 200)
3. Modify the markdown template inside this method
4. Output goes to `data/dossiers/{target_id}/sections/01_sigint.md`

**I want to change how SIGINT is assessed:**
1. The SIGINT data is assessed by ALL 7 assessment types (not just one)
2. To change what pattern_of_life looks for in SIGINT data, see assessment prompts below

**I want to change SIGINT's chat behavior:**
1. Open `agents/sigint_agent.py`
2. The `chat()` method override routes phone queries through the JSON plan
3. Modify `_extract_identifiers()` to change what triggers plan execution

**Files affected by SIGINT changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/sigint.json` |
| Search tool logic | `tools/agent_specific/sigint/sigint_search_tool.py`, `sigint_adapter.py` |
| CDR parsing | `tools/agent_specific/sigint/cdr_query.py` |
| Phone correlation | `tools/agent_specific/sigint/correlation_tool.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_sigint()` |
| Section order | `tools/shared/living_dossier.py` → `SECTION_ORDER` (index 0: "01") |
| Database file | `data/sigint_db.txt` |
| Schema | `schemas/sigint_db.json` |
| Agent class | `agents/sigint_agent.py` |

---

### TRAVEL AGENT — Complete Modification Guide

**I want to change what Travel searches for:**
1. Open `plans/travel.json`
2. Find step with `"tool": "travel_search"`
3. Modify `params.query`

**I want to change how Travel results are analyzed:**
1. Open `plans/travel.json`
2. Find `"action": "analyze"` steps
3. Modify the `"prompt"` strings

**I want to change how Travel data appears in the dossier:**
1. Open `tools/shared/living_dossier.py`
2. Search for `def _format_travel`
3. Modify the markdown template

**I want to change co-traveler detection:**
1. Open `tools/agent_specific/travel/co_traveler_search.py`
2. The `execute()` method contains the matching logic (flight + date)
3. Modify the matching criteria

**Files affected by Travel changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/travel.json` |
| Search tool logic | `tools/agent_specific/travel/travel_search_tool.py` |
| Record parsing | `tools/agent_specific/travel/travel_query.py` |
| Co-traveler logic | `tools/agent_specific/travel/co_traveler_search.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_travel()` |
| Section order | `tools/shared/living_dossier.py` → `SECTION_ORDER` (index 1: "02") |
| Database file | `data/travel_db.txt` |
| Schema | `schemas/travel_db.json` |
| Agent class | `agents/travel_agent.py` |

---

### OSINT AGENT — Complete Modification Guide

**I want to change what OSINT searches for:**
1. Open `plans/osint.json`
2. Modify the search step params

**I want to change how OSINT splits searches:**
1. Open `agents/osint_agent.py`
2. The agent overrides search() to split phone/name queries
3. Modify the splitting logic in the `search()` method

**I want to change how OSINT data appears in the dossier:**
1. Open `tools/shared/living_dossier.py`
2. Search for `def _format_osint`
3. Modify the markdown template

**Files affected by OSINT changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/osint.json` |
| Search splitting | `agents/osint_agent.py` → `search()` override |
| Search tool logic | `tools/agent_specific/osint/osint_search_tool.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_osint()` |
| Database file | `data/osint_db.txt` |
| Schema | `schemas/osint_db.json` |

---

### INTEL REPORTS AGENT — Complete Modification Guide

**Files affected by Intel Reports changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/intel_reports.json` |
| Search tool logic | `tools/agent_specific/intel_reports/intel_reports_search_tool.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_intel_reports()` |
| Database file | `data/intel_reports_db.txt` |
| Schema | `schemas/intel_reports_db.json` |
| Agent class | `agents/intel_reports_agent.py` |

---

### FISA AGENT — Complete Modification Guide

**I want to change FISA auto-expansion (which phones get searched):**
1. Open `agents/fisa_agent.py` or `plans/fisa.json`
2. FISA has special logic for expanding selectors from SIGINT correlation
3. Only PHONE numbers are expanded (not IMEIs/IMSIs — this was a bug fix)

**Files affected by FISA changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/fisa.json` |
| Search tool logic | `tools/agent_specific/fisa/fisa_search_tool.py` |
| FISA record parsing | `tools/agent_specific/fisa/fisa_query.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_fisa()` |
| Database file | `data/fisa_db.txt` |
| Schema | `schemas/fisa_db.json` |

---

### CNE AGENT — Complete Modification Guide

**Files affected by CNE changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/cne.json` |
| Search tool logic | `tools/agent_specific/cne/cne_search_tool.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_cne()` |
| Database file | `data/cne_db.txt` |
| Schema | `schemas/cne_db.json` |
| Agent class | `agents/cne_agent.py` (custom data_path) |

---

### GEOINT AGENT — Complete Modification Guide

**Files affected by GEOINT changes:**
| Change Type | Files |
|-------------|-------|
| Search behavior | `plans/geoint.json` |
| Search tool logic | `tools/agent_specific/geoint/geoint_search_tool.py` |
| Dossier formatting | `tools/shared/living_dossier.py` → `_format_geoint()` |
| Database file | `data/geoint_db.txt` |
| Schema | `schemas/geoint_db.json` |

---

### ACCESS ASSESSMENT AGENT — Complete Modification Guide

**I want to change what Access looks for:**
1. Open `tools/shared/living_dossier.py`
2. Find `ASSESSMENT_TYPES` dict (line ~54)
3. Find the `"access"` key
4. Modify the `"prompt"` string — this is what the LLM scans for in each chunk
5. Modify the `"keywords"` list — these prioritize which chunks get scanned first

**I want to change the Access plan execution:**
1. Open `plans/access.json`
2. This contains the steps for access assessment when using plan_executor mode
3. Add/remove `query_agent` steps to change which data agents are queried

**Actual prompt (in living_dossier.py):**
```python
"access": {
    "title": "ACCESS ASSESSMENT",
    "prompt": (
        "Evaluate what ACCESS this target can provide. Look for:\n"
        "1. POSITION — job title, organization, role, responsibilities\n"
        "2. INFORMATION ACCESS — classified data, trade secrets, government intel\n"
        "3. NETWORK ACCESS — contacts in government, military, organizations\n"
        "4. PHYSICAL ACCESS — facilities, restricted areas, infrastructure\n"
        "5. TECHNICAL ACCESS — systems, databases, communications\n"
        "If this chunk contains relevant evidence, extract with record IDs.\n"
        "If not, respond: NO_INDICATORS\n\n"
        "IMPORTANT: Only report SIGNIFICANT findings..."
    ),
    "keywords": ["position", "director", "ministry", "clearance", "access",
                 "department", "manager", "official", "government", "military",
                 "classified", "restricted", "authorized"],
},
```

**Files affected:**
| Change Type | Files |
|-------------|-------|
| What it scans for | `tools/shared/living_dossier.py` → `ASSESSMENT_TYPES["access"]["prompt"]` |
| Priority keywords | `tools/shared/living_dossier.py` → `ASSESSMENT_TYPES["access"]["keywords"]` |
| Display title | `tools/shared/living_dossier.py` → `ASSESSMENT_TYPES["access"]["title"]` |
| Plan execution | `plans/access.json` |
| Agent class | `agents/access_agent.py` |
| Output file | `data/dossiers/{target_id}/sections/assess_access.md` |
| Narrative section | `tools/shared/living_dossier.py` → `NARRATIVE_SECTIONS` tuple with `"assess_access.md"` |

---

### ACCESSIBILITY ASSESSMENT AGENT — Complete Modification Guide

**Same pattern as Access. Key differences:**
- Dict key: `"accessibility"` in `ASSESSMENT_TYPES`
- Scans for: travel patterns, daily routine, public venues, digital presence, security posture
- Keywords: `["travel", "flight", "hotel", "restaurant", "mosque", "routine", "daily", ...]`
- Plan: `plans/accessibility.json`
- Output: `assess_accessibility.md`

---

### MOTIVATION ASSESSMENT AGENT — Complete Modification Guide

**Same pattern. Key differences:**
- Dict key: `"motivation"` in `ASSESSMENT_TYPES`
- Uses MICE framework: Money, Ideology, Compromise, Ego, Family, Career
- Keywords: `["debt", "loan", "salary", "money", "divorce", "ideology", "affair", ...]`
- Plan: `plans/motivation.json`
- Output: `assess_motivation.md`

---

### SUITABILITY ASSESSMENT AGENT

- Dict key: `"suitability"` — Reliability, cooperation, risk tolerance, stability, discretion
- Plan: `plans/suitability.json`
- Output: `assess_suitability.md`

### SECURITY ASSESSMENT AGENT

- Dict key: `"security"` — Physical security, weapons, counter-surveillance, encrypted comms, hostile environment
- Plan: `plans/security.json`
- Output: `assess_security.md`

### COUNTER-INTEL ASSESSMENT AGENT

- Dict key: `"counter_intel"` — Loyalty, deception, hostile service connections, tradecraft, double agent indicators
- Plan: `plans/counter_intel.json`
- Output: `assess_counter_intel.md`

### PATTERN OF LIFE ASSESSMENT AGENT

- Dict key: `"pattern_of_life"` — Daily routine, weekly patterns, communication patterns, travel patterns, predictability rating
- Plan: `plans/pattern_of_life.json`
- Output: `assess_pattern_of_life.md`

---

### SNA AGENT (Social Network Analysis)

**Special: No database, no plan, no search tool.**
- Synthesizes from ALL other agent results
- Uses `tools/agent_specific/sna/build_network.py` + `analyze_network.py`
- Pure graph algorithms (centrality, clusters)

**To change SNA:**
1. `agents/sna_agent.py` — agent behavior
2. `tools/agent_specific/sna/build_network.py` — how the graph is constructed
3. `tools/agent_specific/sna/analyze_network.py` — graph algorithms

---

## 7. PER-TOOL WALKTHROUGH (What To Change & Where)

### SIGINT Search Tool

| What | File | Exact Location |
|------|------|----------------|
| Search logic | `tools/agent_specific/sigint/sigint_search_tool.py` | `execute()` method |
| Data adapter | `tools/agent_specific/sigint/sigint_adapter.py` | Adapts DB format for search |
| CDR parsing | `tools/agent_specific/sigint/cdr_query.py` | Parse CDR text → structured records |
| Phone correlation | `tools/agent_specific/sigint/correlation_tool.py` | Phone→IMEI→IMSI chains |
| If I change this | Also update: `plans/sigint.json` (if step references change) |

### Travel Search Tool

| What | File | Exact Location |
|------|------|----------------|
| Search logic | `tools/agent_specific/travel/travel_search_tool.py` | `execute()` method |
| Record parsing | `tools/agent_specific/travel/travel_query.py` | Parse travel text → trips |
| Co-traveler | `tools/agent_specific/travel/co_traveler_search.py` | Same flight+date matching |
| If I change this | Also update: `plans/travel.json` |

### FISA Search Tool

| What | File | Exact Location |
|------|------|----------------|
| Search logic | `tools/agent_specific/fisa/fisa_search_tool.py` | `execute()` method |
| FISA parsing | `tools/agent_specific/fisa/fisa_query.py` | Parse FISA orders |
| If I change this | Also update: `plans/fisa.json` |

### CNE / GEOINT / OSINT / Intel Reports Search Tools

All follow the same pattern:
- File: `tools/agent_specific/{agent}/{agent}_search_tool.py`
- Method: `execute()`
- Extends: `base_agent_search_tool.py`
- If changed: also update `plans/{agent}.json`

### Name Variation Generator

| What | File | Exact Location |
|------|------|----------------|
| Arabic/English mappings | `tools/shared/name_variation_generator.py` | Dictionaries at top of class |
| Transliteration rules | Same file | `_generate_arabic_variations()` |
| Max variations | Same file | Return list length |
| If I change this | Nothing else breaks — it's a leaf tool |

### Voter DB Tool

| What | File | Exact Location |
|------|------|----------------|
| Search logic | `tools/shared/voter_db_tool.py` | `execute()` method |
| Database path | `config.py` → `VOTER_CSV_PATH` | Points to `data/voter.csv` |
| If I change this | Nothing else breaks — it's a leaf tool |

### Contact Search Tool

| What | File | Exact Location |
|------|------|----------------|
| Phone discovery logic | `tools/shared/contact_search.py` | `execute()` method |
| Which agents to search | Same file | Agent list in search loop |
| If I change this | Affects enrichment (Step 4 of pipeline) |

### Agent Query Tool (Cross-Agent Bridge)

| What | File | Exact Location |
|------|------|----------------|
| Query routing | `tools/shared/agent_query_tool.py` | `execute()` method |
| Cache prepopulation | Same file | `prepopulate_cache()` method |
| If I change this | Affects ALL assessment agents (they use this to query data agents) |

### Identity Scorer

| What | File | Exact Location |
|------|------|----------------|
| Field weights | `tools/shared/identity_scorer.py` | Top of class (passport=0.95, phone=0.90, etc.) |
| Confidence thresholds | Same file | HIGH≥0.7, MEDIUM=0.4-0.7, LOW<0.4 |
| Name matching | Same file | Jaccard + Arabic variation lookup |
| If I change this | Affects record confidence tags in SQLite |

### Translation Tool

| What | File | Exact Location |
|------|------|----------------|
| Translation logic | `tools/shared/translation_tool.py` | `execute()` method |
| External API config | `config.py` | `TRANSLATION_API_URL`, `TRANSLATION_API_KEY` |
| If I change this | Nothing else breaks — it's a leaf tool |

### Plan Executor

| What | File | Exact Location |
|------|------|----------------|
| Step execution | `tools/shared/plan_executor.py` | `_execute_step()` method |
| Template variable substitution | Same file | `_substitute_templates()` |
| Sub-agent chunking threshold | Same file | `LARGE_PROMPT_THRESHOLD = 6000` |
| MAP prompt (chunk scanning) | Same file | `_chunked_llm_call()` |
| If I change this | Affects ALL agents that use JSON plans (all 14) |

### Tool Calling Engine

| What | File | Exact Location |
|------|------|----------------|
| LLM tool loop | `tools/shared/tool_calling_engine.py` | `run()` method |
| Max iterations | `config.py` | `TOOL_CALLING_MAX_ITERATIONS = 10` |
| Tool definitions | `tools/shared/tool_definitions.py` | JSON schemas list |
| If I change this | Affects chat mode + agents without plans |

### Sub-Agent Processor

| What | File | Exact Location |
|------|------|----------------|
| Worker logic | `tools/shared/sub_agent_processor.py` | `process_chunks()` method |
| Max parallel workers | `config.py` | `SUB_AGENT_MAX_WORKERS = 50` |
| Records per worker | `config.py` | `SUB_AGENT_RECORDS_PER_WORKER = 2` |
| If I change this | Affects large result processing speed |

---

## 8. PER-JSON PLAN WALKTHROUGH

### How Plans Work

Every agent has a JSON plan in `plans/{agent}.json`. When `agent.search()` is called, the `plan_executor.py` reads this JSON and executes steps in order.

### Plan JSON Structure

```json
{
  "version": "4.0",
  "agent_key": "sigint",
  "description": "SIGINT collection and analysis",
  "steps": [
    {
      "id": "step_1",
      "name": "Search CDR records",
      "action": "search",          // or "tool_call", "analyze", "for_each"
      "tool": "sigint_search",
      "params": {
        "query": "{{identifiers}}", // template variable from context
        "max_results": 100
      },
      "output_key": "raw_cdr"      // stored in context for later steps
    },
    {
      "id": "step_2",
      "action": "analyze",
      "prompt": "Analyze: {{raw_cdr}}",  // uses output from step_1
      "max_tokens": 2000,
      "output_key": "analysis"
    }
  ]
}
```

### Template Variables Available

| Variable | What It Contains |
|----------|-----------------|
| `{{identifiers}}` | Full identifiers JSON (name, phone, passport, etc.) |
| `{{phone}}`, `{{name}}`, `{{passport}}` | Individual identifier fields |
| `{{output_key_from_previous_step}}` | Output from any earlier step |
| `{{dossier_context}}` | Compiled dossier text (for assessment plans) |

### Step Actions

| Action | What It Does | Uses LLM? |
|--------|-------------|-----------|
| `search` | Execute a search tool against text DB | No |
| `tool_call` | Execute any registered tool | No |
| `analyze` | Send prompt to LLM for analysis | Yes |
| `for_each` | Iterate over array results | Depends on sub-steps |

### Per-Plan Modification Guide

#### `plans/sigint.json` — SIGINT Plan

**Steps:** correlate → CDR query → network analysis → compile
**To modify:**
1. Open `plans/sigint.json`
2. To change search queries: modify step_1 `params`
3. To change analysis prompts: modify step_3 and step_4 `prompt`
4. To add cross-reference: add a `tool_call` step with `"tool": "query_agent"`
5. To change output compilation: modify the last step's `prompt`

#### `plans/travel.json` — Travel Plan

**Steps:** search → extract routes → analyze patterns → co-travelers → compile
**To modify:**
1. Open `plans/travel.json`
2. To change what's searched: modify step_1 `params`
3. To disable co-traveler: remove the co_traveler step
4. To add a cross-reference step: add `{"action": "tool_call", "tool": "query_agent", "params": {"agent_key": "sigint", "query": "{{phone}}"}}`

#### `plans/osint.json` — OSINT Plan
#### `plans/intel_reports.json` — Intel Reports Plan
#### `plans/fisa.json` — FISA Plan
#### `plans/cne.json` — CNE Plan
#### `plans/geoint.json` — GEOINT Plan

All follow the same pattern: search → analyze → compile. Modify `params` to change search, modify `prompt` to change analysis.

#### `plans/access.json` — Access Assessment Plan

**Key difference from data agents:** Assessment plans query OTHER agents via `query_agent` tool, then receive `{{dossier_context}}` to analyze.

**Steps:** expand identifiers → query intel_reports → query osint → query sigint → query cne → assess → compile
**To change which data agents are queried:**
1. Add/remove `query_agent` steps
2. Modify `params.agent_key` to target different agents

#### `plans/accessibility.json` — Queries: travel, geoint, meta, osint
#### `plans/motivation.json` — Queries: intel_reports, osint, cne, sigint
#### `plans/suitability.json` — Queries: intel_reports, osint, cne, sigint
#### `plans/security.json` — Queries: intel_reports, sigint, geoint, osint, cne, fisa
#### `plans/counter_intel.json` — Queries: sigint, travel, fisa, intel_reports, cne
#### `plans/pattern_of_life.json` — Queries: sigint, travel, geoint, meta, cne

---

## 9. HOW TO CHANGE REPORT PROMPTS

### Executive Summary

**File:** `tools/shared/living_dossier.py`
**Method:** `generate_executive_summary()`

**Step-by-step:**
1. Open `tools/shared/living_dossier.py`
2. Search for `def generate_executive_summary`
3. Find the prompt string passed to `self.llm.chat()`
4. Modify the prompt text
5. Available context: `{target_identity}` (injected as "TARGET: Name (Phone: +xxx)")
6. The compiled dossier text is passed as the user message content
7. To change output length: modify `max_tokens=4000`

---

### Narrative Report (Targeting Mode — 11 sections from assessments)

**File:** `tools/shared/living_dossier.py`
**Method:** `generate_narrative_report()`
**Location:** Line ~1232 (the `if has_assessments:` branch)

**Structure:** List of tuples: `(section_key, title, assess_file, prompt)`

```python
NARRATIVE_SECTIONS = [
    ("executive_overview", "Executive Overview", None,
     "Write a 1-paragraph executive overview of this intelligence target. "
     "State who they are, why they matter, overall risk level, and key recommendation."),
    ("target_background", "Target Background", None,
     "Write 1-2 paragraphs describing who this target is..."),
    ("access", "Access Assessment", "assess_access.md",
     "Write 1-2 paragraphs analyzing what intelligence access..."),
    ("accessibility", "Accessibility Assessment", "assess_accessibility.md",
     "Write 1-2 paragraphs on how accessible this target is..."),
    ("motivation", "Motivation & Vulnerabilities", "assess_motivation.md",
     "Write 1-2 paragraphs analyzing motivation using MICE..."),
    ("suitability", "Suitability Assessment", "assess_suitability.md",
     "Write 1-2 paragraphs on suitability for engagement..."),
    ("security", "Security Assessment", "assess_security.md",
     "Write 1-2 paragraphs on security risks..."),
    ("counter_intel", "Counter-Intelligence Assessment", "assess_counter_intel.md",
     "Write 1-2 paragraphs on CI risks..."),
    ("pattern_of_life", "Pattern of Life", "assess_pattern_of_life.md",
     "Write 1-2 paragraphs describing daily routine..."),
    ("network", "Network Analysis", None,
     "Write 1 paragraph summarizing contact network..."),
    ("recommendations", "Risk Assessment & Recommendations", None,
     "Write 1-2 paragraphs with risk level and recommendations..."),
]
```

**Step-by-step to modify:**
1. To change section prompt: modify the 4th element (prompt string) in the tuple
2. To change section title: modify the 2nd element
3. To change which assessment file feeds it: modify the 3rd element (filename or None)
4. To add a section: add a new tuple to the list
5. To remove a section: remove the tuple
6. To reorder: move tuples up/down in the list

---

### Narrative Report (LEO/Trace Mode — 11 sections from data sources)

**File:** `tools/shared/living_dossier.py`
**Method:** `generate_narrative_report()`
**Location:** Line ~1270 (the `else:` branch — no assessments)

```python
NARRATIVE_SECTIONS = [
    ("executive_overview", "Executive Overview", None, "..."),
    ("target_background", "Target Background", None, "..."),
    ("communications", "Communications & SIGINT Analysis", "01_sigint.md", "..."),
    ("travel", "Travel & Movement Patterns", "02_travel.md", "..."),
    ("digital", "Digital Footprint & Device Data", "03_cne.md", "..."),
    ("fisa", "Legal Intercepts & FISA", "04_fisa.md", "..."),
    ("osint", "Open Source Intelligence", "05_osint.md", "..."),
    ("intel", "Intelligence Reporting", "06_intel_reports.md", "..."),
    ("geoint", "Geospatial Intelligence", "07_geoint.md", "..."),
    ("network", "Network Analysis", None, "..."),
    ("recommendations", "Risk Assessment & Recommendations", None, "..."),
]
```

Same modification pattern as targeting mode.

---

### Trace Report Narrative Topics

**File:** `tools/shared/trace_report_synthesizer.py`
**Method:** `_generate_narrative()`
**Location:** Line ~289

**Structure:** Tuples of `(topic_key, title, agent_keys_list, prompt)`

```python
NARRATIVE_TOPICS = [
    ("communications", "Communications & SIGINT Activity",
     ["sigint"],
     "Write 2-3 paragraphs about the target's communications activity..."),
    ("travel", "Travel & Movement Patterns",
     ["travel", "geoint"],
     "Write 2-3 paragraphs about the target's travel and movement patterns..."),
    ("digital", "Digital Footprint & Device Data",
     ["cne", "osint"],
     "Write 1-2 paragraphs about the target's digital footprint..."),
    ("intel_reports", "Intelligence Reporting",
     ["intel_reports"],
     "Write 1-2 paragraphs summarizing intelligence reports..."),
    ("legal_intercepts", "Legal Intercepts & FISA",
     ["fisa"],
     "Write 1-2 paragraphs about FISA or legal intercept records..."),
]
```

**Step-by-step to modify:**
1. To change which agents feed a topic: modify the 3rd element (agent_keys list)
2. To change the LLM prompt: modify the 4th element
3. To add a topic: add a new tuple
4. Topics generate in PARALLEL (ThreadPoolExecutor)

---

### Assessment Scan Prompts (7 types)

**File:** `tools/shared/living_dossier.py`
**Dict:** `ASSESSMENT_TYPES` (starts at line ~54)

**Step-by-step to modify ANY assessment:**
1. Open `tools/shared/living_dossier.py`
2. Find `ASSESSMENT_TYPES = {`
3. Find the key you want to change: `"access"`, `"accessibility"`, `"motivation"`, `"suitability"`, `"security"`, `"counter_intel"`, `"pattern_of_life"`
4. Modify the `"prompt"` string — numbered criteria that the LLM looks for
5. Modify the `"keywords"` list — chunks with these words get scanned FIRST
6. The `"title"` becomes the heading in the assessment output

**Assessment prompt format (all follow this pattern):**
```python
"prompt": (
    "Evaluate {WHAT} for this target. Look for:\n"
    "1. CRITERION_1 — what to look for\n"
    "2. CRITERION_2 — what to look for\n"
    "...\n"
    "If this chunk contains relevant evidence, extract with record IDs.\n"
    "If not, respond: NO_INDICATORS\n\n"
    "IMPORTANT: Only report SIGNIFICANT findings..."
),
```

---

### Section Summaries

**File:** `tools/shared/living_dossier.py`
**Methods:** `summarize_section()` → `_single_summary()` and `_chunked_summary()`

**Step-by-step:**
1. `_single_summary()` — used when section fits in one chunk
   - Find the prompt string asking for "concise summary"
   - Receives `identifiers` for target identity context
2. `_chunked_summary()` — MAP/REDUCE for large sections
   - MAP prompt: "Extract relevant facts from this chunk"
   - REDUCE prompt: "Synthesize into coherent summary"
   - Both accept `identifiers` to inject target identity

---

## 10. HOW TO CHANGE REPORT FORMATTING

### Dossier Section Formatters

**File:** `tools/shared/living_dossier.py`

Each data agent has a dedicated formatter converting raw records into markdown:

| Agent | Method | Output Format |
|-------|--------|---------------|
| SIGINT | `_format_sigint()` | `#### CONTACT: +phone (N interactions)\n- Date, duration, type` |
| Travel | `_format_travel()` | `#### Record: Departure→Arrival\n- Date, flight, passport` |
| FISA | `_format_fisa()` | `#### Report: SELECTOR\n- Content, dates` |
| CNE | `_format_cne()` | `#### Record: Operation\n- Files, tools, dates` |
| Intel Reports | `_format_intel_reports()` | `#### Report: Title\n- Source, content` |
| OSINT | `_format_osint()` | `#### Record: Source\n- Content, entities` |
| GEOINT | `_format_geoint()` | `#### Record: Location\n- Coordinates, imagery` |
| Generic | `_format_generic()` | Fallback key-value formatting |

**Step-by-step to change formatting:**
1. Open `tools/shared/living_dossier.py`
2. Search for `def _format_{agent}` (e.g., `_format_sigint`)
3. The method receives a list of raw records
4. Modify the markdown template/structure inside
5. Output goes to `data/dossiers/{target_id}/sections/{NN}_{agent}.md`
6. Changes affect ALL future dossier compilations

### Section Order

**File:** `tools/shared/living_dossier.py`
**Constant:** `SECTION_ORDER` (line ~39)

```python
SECTION_ORDER = [
    ("sigint", "01", "SIGINT INTELLIGENCE"),
    ("travel", "02", "TRAVEL INTELLIGENCE"),
    ("cne", "03", "CNE INTELLIGENCE"),
    ("fisa", "04", "FISA INTELLIGENCE"),
    ("osint", "05", "OPEN SOURCE INTELLIGENCE"),
    ("intel_reports", "06", "INTELLIGENCE REPORTS"),
    ("geoint", "07", "GEOSPATIAL INTELLIGENCE"),
    ("meta", "08", "METADATA INTELLIGENCE"),
]
```

**Step-by-step to change order:**
1. Swap the number strings (2nd element) between tuples
2. Files are named: `{number}_{agent_key}.md`

### Cross-Reference Format

**Method:** `compile_cross_references()` in `living_dossier.py`
- Pure Python regex (zero LLM)
- Scans all section files for shared identifiers (phones, IMEIs, emails, passports)
- Outputs markdown table: `| Identifier | Type | Found In |`

**Step-by-step to modify:**
1. Find `compile_cross_references()` or `_compile_cross_references()`
2. To add new identifier types: add regex patterns
3. To change output format: modify the markdown template at end of method
4. To exclude target's own identifiers: the method accepts `identifiers` param for filtering

### Contact Network Format

**Method:** `compile_contact_network()` in `living_dossier.py`
- Pure Python (zero LLM)
- Extracts phone numbers from all sections
- Resolves names via `_resolve_contact_names()` (regex proximity matching)
- Counts interactions per agent

**Output format:**
```markdown
## Contact Network

### Known Contacts
- **Ahmad Hassan** (+964-770-xxx) — 47 interactions (SIGINT: 35, FISA: 12)
- **Unknown** (+964-750-xxx) — 8 interactions (SIGINT: 8)
```

---

## 11. API ENDPOINTS REFERENCE

### Core Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/` | Health check |
| GET | `/agents` | List all 15 agents |
| POST | `/target-card` | Run full pipeline (SSE) |
| POST | `/single-agent` | Query one agent |
| POST | `/agentic-search` | Free-text tool-calling search |

### LEO Workflows

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/leo/create` | Create LEO |
| GET | `/leo/list` | List all LEOs |
| POST | `/leo/run/{leo_id}` | Execute LEO pipeline |
| GET | `/leo/{leo_id}/results` | Get results |
| DELETE | `/leo/delete/{leo_id}` | Delete LEO |
| POST | `/leo/schedule/{leo_id}` | Schedule periodic runs |

### Targeting Workflows

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/targeting/create` | Create targeting workflow |
| GET | `/targeting/list` | List all |
| POST | `/targeting/run/{wf_id}` | Execute targeting pipeline |
| GET | `/targeting/{wf_id}/results` | Get results |
| DELETE | `/targeting/{wf_id}` | Delete workflow |

### Trace Workflows

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/trace/create` | Create trace |
| GET | `/trace/list` | List all |
| POST | `/trace/run/{wf_id}` | Execute trace pipeline |
| GET | `/trace/{tr_id}/results` | Get trace report |

### Chat

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | `/chat/start` | Start chat session |
| POST | `/chat/message` | Send message |
| GET | `/chat/history/{session_id}` | Get history |

### Dossier

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/targets/{target_id}/dossier` | Compiled dossier text |
| GET | `/targets/{target_id}/dossier/sections` | List section files |
| GET | `/targets/{target_id}/dossier/sections/{name}` | Single section |
| GET | `/targets/{target_id}/dossier/versions` | Version history |
| GET | `/targets/{target_id}/dossier/narrative` | Narrative report |

### Events (SSE)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/events/{run_id}` | Live SSE stream |
| GET | `/events/{run_id}/history` | Past events |
| GET | `/pipeline/result/{run_id}` | Final result |

### Targets & Records

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/targets` | All targets |
| GET | `/targets/{target_id}/records` | All records |
| DELETE | `/targets/{target_id}/records/{record_id}` | Soft-delete |
| GET | `/targets/{target_id}/reports/latest` | Latest report |

---

## 12. CONFIGURATION REFERENCE

**File:** `config.py` (94 lines)

### All Settings

| Variable | Default | What It Controls |
|----------|---------|-----------------|
| **LLM** | | |
| `LLM_BASE_URL` | "" | Custom LLM endpoint |
| `LLM_API_KEY` | "" | API key for custom endpoint |
| `LLM_MODEL` | "" | Model name override |
| `LLM_PROVIDER` | "" | Provider type (openai schema) |
| `LLM_MAX_CALLS_PER_TARGET` | 300 | Safety cap per target run |
| `OPENAI_API_KEY` | — | OpenAI key |
| `ANTHROPIC_API_KEY` | — | Anthropic key |
| `GOOGLE_API_KEY` | — | Google AI key |
| `DEFAULT_LLM_PROVIDER` | "openai" | Which provider by default |
| `DEFAULT_MODEL` | "gpt-4o-mini" | Which model by default |
| `LLM_FAILOVER_ORDER` | openai,anthropic,google | Failover chain |
| `LLM_TIMEOUT_SECONDS` | 30 | Request timeout |
| **Paths** | | |
| `BASE_DIR` | auto-detected | Backend root |
| `DATA_DIR` | `{BASE_DIR}/data` | Data files |
| `DOSSIERS_DIR` | `{DATA_DIR}/dossiers` | Dossier output |
| `TOOLS_DIR` | `{BASE_DIR}/tools` | Tools directory |
| `GLOBAL_TOOLS_DIR` | `{TOOLS_DIR}/shared` | Shared tools |
| `AGENT_TOOLS_BASE` | `{TOOLS_DIR}/agent_specific` | Per-agent tools |
| **Databases** | | |
| `SIGINT_DB` | `{DATA_DIR}/sigint_db.txt` | SIGINT records |
| `TRAVEL_DB` | `{DATA_DIR}/travel_db.txt` | Travel records |
| `OSINT_DB` | `{DATA_DIR}/osint_db.txt` | OSINT records |
| `INTEL_REPORTS_DB` | `{DATA_DIR}/intel_reports_db.txt` | Intel reports |
| `FISA_DB` | `{DATA_DIR}/fisa_db.txt` | FISA records |
| `CNE_DB` | `{DATA_DIR}/cne_db.txt` | CNE records |
| `GEOINT_DB` | `{DATA_DIR}/geoint_db.txt` | GEOINT records |
| `CORRELATION_DB` | `{DATA_DIR}/correlation_db.txt` | Correlation data |
| `ACCESS_DB` | `{DATA_DIR}/access_db.txt` | Access data |
| `ACCESSIBILITY_DB` | `{DATA_DIR}/accessibility_db.txt` | Accessibility data |
| `MOTIVATION_DB` | `{DATA_DIR}/motivation_db.txt` | Motivation data |
| `SUITABILITY_DB` | `{DATA_DIR}/suitability_db.txt` | Suitability data |
| `SECURITY_DB` | `{DATA_DIR}/security_db.txt` | Security data |
| `COUNTER_INTEL_DB` | `{DATA_DIR}/counter_intel_db.txt` | Counter-intel data |
| `PATTERN_OF_LIFE_DB` | `{DATA_DIR}/pattern_of_life_db.txt` | Pattern of life data |
| `VOTER_CSV_PATH` | `{DATA_DIR}/voter.csv` | Voter CSV |
| `TARGET_STORE_DB_PATH` | `{DATA_DIR}/target_store.db` | Target SQLite |
| `RESULTS_DB_PATH` | `{DATA_DIR}/results_store.db` | Results SQLite |
| **Tool Calling** | | |
| `TOOL_CALLING_MAX_ITERATIONS` | 10 | Max tool-call loops in chat |
| `TOOL_CALLING_MAX_MISTAKES` | 3 | Max errors before abort |
| **Sub-Agent Processing** | | |
| `SUB_AGENT_RECORDS_PER_WORKER` | 2 | Records per sub-agent chunk |
| `SUB_AGENT_MAX_WORKERS` | 50 | Max parallel workers |
| **Living Dossier** | | |
| `DOSSIER_CHUNK_SIZE` | 3000 | Assessment chunk size (chars) |
| `DOSSIER_SUMMARY_THRESHOLD` | 6000 | When to use chunked summary |
| `DOSSIER_MAX_SUB_AGENT_WORKERS` | 4 | Parallel assessment workers |
| `LARGE_DATA_CHUNK_SIZE` | 3000 | Legacy chunk size |
| `MAX_SUB_WORKERS` | 10 | Legacy max workers |
| **Enrichment** | | |
| `ENRICHMENT_MAX_ITERATIONS` | 3 | Max enrichment loops |
| `ENRICHMENT_MAX_NEW_PER_ITERATION` | 10000 | Max new IDs per iteration |
| `ENRICHMENT_ENABLED` | true | Enable/disable enrichment |
| **Translation** | | |
| `TRANSLATION_API_URL` | "" | External translation API |
| `TRANSLATION_API_KEY` | "" | Translation API key |
| **Server** | | |
| `API_HOST` | "0.0.0.0" | Bind address |
| `API_PORT` | 8000 | Bind port |
| `MAX_TOKENS` | 2000 | Default LLM max tokens |
| `TEMPERATURE` | 0.3 | Default LLM temperature |

---

## 13. DEPENDENCY MAP (If I Change X, What Breaks?)

### Critical Files — Change These Carefully

| File Changed | Files That Break |
|--------------|-----------------|
| `config.py` | **ALL files** (everyone imports Config) |
| `llm_provider.py` | plan_executor, tool_calling_engine, sub_agent_processor, living_dossier, trace_report_synthesizer, base_agent, orchestrator, chat_manager |
| `base_agent.py` | ALL 14 agent files (they extend BaseAgent) |
| `orchestrator.py` | api_server, leo_manager, targeting_manager |
| `target_store.py` | orchestrator, api_server, dossier_pipeline, living_dossier, enrichment_tracker, agent_query_tool, cross_target_linker, entity_resolver, leo_manager, targeting_manager, chat_manager |
| `living_dossier.py` | dossier_pipeline (only caller) |
| `dossier_pipeline.py` | orchestrator, leo_manager, targeting_manager |
| `plan_executor.py` | base_agent (all agents use it) |
| `tool_calling_engine.py` | base_agent, chat_manager |
| `tool_definitions.py` | tool_calling_engine |
| `base_agent_search_tool.py` | ALL 7 data agent search tools |
| `event_bus.py` | api_server, dossier_pipeline |

### Safe to Change (Leaf Nodes — Nothing Imports Them)

- `main.py` — entry point only
- `index.html` — frontend, standalone
- `test_e2e.py`, `test_reallife.py` — tests
- Individual agent files (e.g., `sigint_agent.py`) — only orchestrator imports them
- Plan JSON files — only plan_executor reads them at runtime
- Schema JSON files — only search tools reference them
- `name_variation_generator.py` — leaf utility
- `voter_db_tool.py` — leaf utility
- `datetime_tool.py` — leaf utility
- `translation_tool.py` — leaf utility
- SNA tools (`build_network.py`, `analyze_network.py`) — only sna_agent imports

### Dependency Chain

```
api_server → orchestrator → base_agent → plan_executor → sub_agent_processor → llm_provider
                          → dossier_pipeline → living_dossier → llm_provider
                                            → trace_report_synthesizer → llm_provider
                          → target_store

api_server → leo_manager → dossier_pipeline (same chain)
api_server → targeting_manager → dossier_pipeline (same chain)
api_server → chat_manager → tool_calling_engine → llm_provider
```

---

## APPENDIX: AIR-GAP LOCAL LLM SETUP

For air-gapped deployment without external API access:

```bash
# In .env:
LLM_PROVIDER=local
LLM_BASE_URL=http://localhost:11434/v1   # Ollama example
LLM_MODEL=llama3.1:70b
LLM_API_KEY=not-needed
```

The platform uses OpenAI-compatible API format (`/v1/chat/completions`). Any server exposing this works.

Recommended: 70B+ parameters for assessment quality. Smaller models (7B-13B) work for MAP/chunking tasks.

---

## APPENDIX: HOW TO ADD A NEW DATA AGENT (Full Walkthrough)

1. **Create agent file** — `agents/new_data_agent.py`:
   ```python
   from agents.base_agent import BaseAgent
   class NewDataAgent(BaseAgent):
       agent_key = "new_data"
       agent_name = "New Data Agent"
   ```

2. **Create database** — `data/new_data_db.txt` with records

3. **Create schema** — `schemas/new_data_db.json` with field definitions

4. **Create search tool** — `tools/agent_specific/new_data/new_data_search_tool.py`:
   ```python
   from tools.agent_specific.base_agent_search_tool import BaseAgentSearchTool
   class NewDataSearchTool(BaseAgentSearchTool):
       # Point to your database file
       pass
   ```

5. **Add config** — `config.py`: `NEW_DATA_DB = os.path.join(DATA_DIR, "new_data_db.txt")`

6. **Create plan** — `plans/new_data.json` with execution steps

7. **Register in orchestrator** — `orchestrator.py` → `_register_agents()` method

8. **Add to pipeline** — `dossier_pipeline.py` → `DATA_AGENTS` list

9. **Add section order** — `living_dossier.py` → `SECTION_ORDER` list (add tuple)

10. **Add formatter** — `living_dossier.py` → create `_format_new_data()` method (or it uses `_format_generic`)

---

## APPENDIX: HOW TO ADD A NEW ASSESSMENT TYPE (Full Walkthrough)

1. **Add to ASSESSMENT_TYPES** — `living_dossier.py`:
   ```python
   "my_assessment": {
       "title": "MY ASSESSMENT",
       "prompt": "Evaluate the target for... Look for:\n1. ...\n2. ...\n"
                 "If this chunk contains relevant evidence, extract with record IDs.\n"
                 "If not, respond: NO_INDICATORS",
       "keywords": ["keyword1", "keyword2"],
   },
   ```

2. **Create agent** — `agents/my_assessment_agent.py`

3. **Create plan** — `plans/my_assessment.json` (copy from `access.json` as template)

4. **Register in orchestrator** — `orchestrator.py`

5. **Add to pipeline** — `dossier_pipeline.py` → `ASSESSMENT_AGENTS` list

6. **Add to narrative** — `living_dossier.py` → add tuple to `NARRATIVE_SECTIONS` (targeting mode)

---

## 14. WORKFLOW MODIFICATION — STEP-BY-STEP

### Understanding the 3 Workflows

All 3 workflows use the SAME 7-step pipeline (`dossier_pipeline.py`). The ONLY difference:

| Workflow | Who Calls Pipeline | `workflow_type` param | Step 6 (Assess) | Step 7 (Final) |
|----------|-------------------|----------------------|-----------------|----------------|
| **Targeting** | `targeting_manager.py` | `"targeting"` | RUNS 7 assessments | Narrative from assessment files |
| **Trace** | `targeting_manager.py` | `"trace"` | SKIPPED | `trace_report_synthesizer.py` |
| **LEO** | `leo_manager.py` | `"leo"` | SKIPPED | Narrative from data source files |

---

### I WANT TO: Change which agents run in a workflow

**File:** `tools/shared/dossier_pipeline.py` (line ~31)

```python
DATA_AGENTS = [
    "travel", "osint", "intel_reports", "sigint", "fisa", "cne", "geoint",
]
```

**Steps:**
1. Open `tools/shared/dossier_pipeline.py`
2. Find `DATA_AGENTS` list at top of class (line ~31)
3. Add or remove agent keys from this list
4. These agents run in Step 3 (COLLECT) for ALL workflows

**To change agents for ONE specific workflow only:**
1. The `run()` method accepts `agent_keys` parameter (optional subset)
2. This is passed from the calling manager
3. For targeting: `targeting_manager.py` → find where `pipeline.run()` is called
4. For LEO: `leo_manager.py` → find where `pipeline.run()` is called
5. Pass `agent_keys=["sigint", "travel"]` to limit which agents run

---

### I WANT TO: Change which assessments run

**File:** `tools/shared/dossier_pipeline.py` (line ~34)

```python
ASSESSMENT_AGENTS = [
    "access", "accessibility", "motivation", "suitability",
    "security", "counter_intel", "pattern_of_life",
]
```

**Steps:**
1. Open `tools/shared/dossier_pipeline.py`
2. Find `ASSESSMENT_AGENTS` list (line ~34)
3. Add or remove assessment type keys
4. These only run in Step 6 (targeting workflow only)
5. Must also have matching entry in `ASSESSMENT_TYPES` dict in `living_dossier.py`

---

### I WANT TO: Change Step 2 (EXPAND) — how identifiers are expanded

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `_step_2_expand()` (line ~211)

**What this step does:**
- Takes user-provided identifiers (name, phone, passport)
- Generates 18+ Arabic/English name transliterations via `name_variation_generator`
- Runs phone correlation to find linked IMEIs/IMSIs
- Stores expanded identifiers for all subsequent searches

**Steps to modify:**
1. Open `tools/shared/dossier_pipeline.py`
2. Find `def _step_2_expand(self, identifiers)`
3. To change name expansion: modify the call to `self.orch._auto_expand_query()`
4. To change which identifier fields trigger expansion: modify the `meaningful` check (line ~220)
5. To add a new expansion type (e.g., email domain expansion): add logic after the phone correlation

**Related files:**
- `tools/shared/name_variation_generator.py` — actual Arabic/English dictionaries
- `tools/agent_specific/sigint/correlation_tool.py` — phone→IMEI→IMSI chains
- `agents/orchestrator.py` → `_auto_expand_query()` method

---

### I WANT TO: Change Step 3 (COLLECT) — how agents are run

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `_step_3_collect()` (line ~278)

**What this step does:**
- Runs 7 data agents in parallel (ThreadPoolExecutor, max 5 workers)
- Each agent: `agent.search(identifiers)` via plan_executor
- Results written to dossier sections via `dossier.write_agent_section()`
- Sections summarized via `dossier.summarize_section()`

**Steps to modify:**
1. Open `tools/shared/dossier_pipeline.py`
2. Find `def _step_3_collect()`
3. To change concurrency: modify `max_workers = min(5, len(data_agents))` (line ~327)
4. To change what happens after agent runs: modify the post-processing after `_run_agent()`
5. To add a hook after each agent completes: add code after `dossier.write_agent_section()`

**To change how an individual agent searches:**
- Edit that agent's plan JSON file (see Section 8 above)
- OR override `search()` in the agent class file

---

### I WANT TO: Change Step 4 (ENRICH) — iterative discovery

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `_step_4_enrich()` (line ~533)

**What this step does:**
- Scans existing results for new phone numbers (via `contact_search`)
- For each new identifier found, searches relevant agents again
- Appends new results to existing sections
- Loops until convergence or max iterations (default 3)

**Steps to modify:**
1. Open `tools/shared/dossier_pipeline.py`
2. Find `def _step_4_enrich()`
3. To change max iterations: modify `config.py` → `ENRICHMENT_MAX_ITERATIONS` (default 3)
4. To disable enrichment: set `ENRICHMENT_ENABLED=false` in .env
5. To change what's considered a "new identifier": modify `contact_search.py` → `execute()`
6. To change which agents get re-searched: modify the agent selection logic in this method

**Related files:**
- `tools/shared/enrichment_tracker.py` — tracks discovered identifiers, prevents infinite loops
- `tools/shared/contact_search.py` — finds new phone numbers across all databases
- `config.py` → `ENRICHMENT_MAX_ITERATIONS`, `ENRICHMENT_MAX_NEW_PER_ITERATION`, `ENRICHMENT_ENABLED`

---

### I WANT TO: Change Step 5 (COMPILE) — cross-references and contact network

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `_step_5_compile()` (line ~718)

**What this step does (zero LLM, all Python):**
1. `compile_cross_references()` — regex scan for shared identifiers
2. `compile_contact_network()` — phone extraction + name resolution
3. Voter registration check
4. Entity resolution + cross-target links
5. Compile full dossier (concatenate all sections into versioned file)

**Steps to modify:**
1. To change cross-references: `living_dossier.py` → `compile_cross_references()` (see Section 10)
2. To change contact network: `living_dossier.py` → `compile_contact_network()` (see Section 10)
3. To add a new compilation sub-step: add code after step 5d in `_step_5_compile()`
4. To change voter lookup: modify `_check_voter_registration()` in same file
5. To change cross-target linking: modify `tools/shared/cross_target_linker.py`

---

### I WANT TO: Change Step 6 (ASSESS) — assessment scanning

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `_step_6_assess()` (line ~801)

**What this step does:**
- Reads the compiled dossier from disk
- For each of 7 assessment types, calls `dossier.run_assessment(type)`
- Each assessment: chunks dossier into 3K segments → LLM scans each chunk
- Results saved to `assess_{type}.md`

**Steps to modify:**
1. To change assessment prompts: modify `ASSESSMENT_TYPES` in `living_dossier.py` (Section 9)
2. To change chunk size: `config.py` → `DOSSIER_CHUNK_SIZE` (default 3000)
3. To change which chunks are skipped: `living_dossier.py` → `_is_pure_index_chunk()`
4. To change keyword pre-filtering: modify `keywords` list in `ASSESSMENT_TYPES`
5. To run assessments in parallel vs serial: modify executor in `_step_6_assess()`
6. To skip specific assessments: remove from `ASSESSMENT_AGENTS` list in `dossier_pipeline.py`

**This step only runs for `workflow_type == "targeting"`.** Trace and LEO skip it.

---

### I WANT TO: Change Step 7 (FINAL) — report generation

**File:** `tools/shared/dossier_pipeline.py`
**Methods:**
- `_step_7_final()` (line ~923) — for targeting and LEO
- `_step_7_trace_report()` (line ~848) — for trace

**For targeting/LEO final:**
1. Calls `dossier.generate_executive_summary()` → LLM generates 4000-token summary
2. Calls `dossier.generate_narrative_report()` → LLM generates 11-section narrative
3. Stores report in target_store

**For trace final:**
1. Calls `trace_report_synthesizer.synthesize_trace_report()` → generates trace-specific report
2. Also generates executive summary and narrative

**Steps to modify:**
1. To change executive summary: see Section 9 → "Executive Summary"
2. To change narrative sections: see Section 9 → "Narrative Report"
3. To change trace report: see Section 9 → "Trace Report Narrative Topics"
4. To add a new step after the report: add code after `_step_7_final()` returns
5. To change what gets stored in SQLite: modify the `store.store_report()` call in the method

---

### I WANT TO: Make a workflow skip or add a step

**File:** `tools/shared/dossier_pipeline.py`
**Method:** `run()` (line ~53)

The `run()` method is the master controller. Steps are called sequentially:

```python
# In run() method:
dossier_dir = self.dossier.create_dossier(...)        # Step 1
identifiers = self._step_2_expand(identifiers)        # Step 2
raw_results, ... = self._step_3_collect(...)          # Step 3
enrichment_stats = self._step_4_enrich(...)           # Step 4
dossier_path = self._step_5_compile(...)              # Step 5
if workflow_type not in ("trace", "leo"):             # Step 6 (conditional)
    assessments = self._step_6_assess(target_id)
if workflow_type == "trace":                          # Step 7 (branched)
    ... = self._step_7_trace_report(...)
else:
    ... = self._step_7_final(...)
```

**To skip a step for a specific workflow:**
1. Add a condition: `if workflow_type != "my_type": self._step_X()`
2. Example: to skip enrichment for trace: wrap Step 4 in `if workflow_type != "trace":`

**To add a new step:**
1. Create a new method: `def _step_X_my_step(self, ...)`
2. Call it from `run()` at the desired position
3. Add SSE event emission: `self._emit("my_step_started", message="...")`

---

### I WANT TO: Change the API endpoint for a workflow

**File:** `api_server.py`

**Targeting workflow endpoints:** Search for `@app.post("/targeting/`
**LEO workflow endpoints:** Search for `@app.post("/leo/`
**Trace workflow endpoints:** Search for `@app.post("/trace/`

**Steps:**
1. Open `api_server.py`
2. Find the endpoint (e.g., `@app.post("/targeting/run/{wf_id}")`)
3. The endpoint handler calls the manager (e.g., `targeting_manager.run_workflow()`)
4. The manager calls `dossier_pipeline.run(workflow_type="targeting")`
5. To change request format: modify the endpoint function parameters
6. To change response format: modify the return dict

**Chain:**
```
Frontend → api_server.py (endpoint) → {leo,targeting}_manager.py → dossier_pipeline.run() → 7 steps
```

---

## 15. EDITING AN EXISTING TOOL — COMPLETE WALKTHROUGH

### What Is a "Tool"?

A tool is a Python class with an `execute(params: dict) -> dict` method. Tools are called by:
1. **Plan Executor** — deterministic JSON steps call tools by name
2. **Tool Calling Engine** — LLM autonomously decides which tools to call
3. **Pipeline** — some tools called directly by pipeline steps

### Step-by-Step: Edit an Agent Search Tool

**Example: I want to change how the SIGINT search works**

1. **Open the tool file:**
   ```
   tools/agent_specific/sigint/sigint_search_tool.py
   ```

2. **Find the `execute()` method** — this is the entry point. It receives `params` dict and returns results dict.

3. **Understand the inheritance:**
   - `SIGINTSearchTool` extends `BaseAgentSearchTool` (in `tools/agent_specific/base_agent_search_tool.py`)
   - `BaseAgentSearchTool` provides: text file loading, regex search, scoring, ranking
   - Override `execute()` to change behavior completely, OR modify parent class to change ALL search tools

4. **Modify the search logic:**
   - To change scoring: modify the scoring algorithm in `base_agent_search_tool.py`
   - To change what gets returned: modify the return dict structure
   - To add filtering: add filter logic after search results are gathered

5. **Test the change:**
   ```bash
   python -c "
   from tools.agent_specific.sigint.sigint_search_tool import SIGINTSearchTool
   tool = SIGINTSearchTool('data/sigint_db.txt')
   result = tool.execute({'query': '+964-770-555-1234'})
   print(result.keys(), len(str(result)))
   "
   ```

6. **Check downstream effects:**
   - The plan JSON (`plans/sigint.json`) references this tool by name
   - If you changed the return dict keys, update the plan's next step that uses `{{output_key}}`
   - The `_format_sigint()` method in `living_dossier.py` expects a certain input format

### Step-by-Step: Edit a Shared Tool

**Example: I want to change how name_variation_generator works**

1. **Open:** `tools/shared/name_variation_generator.py`

2. **Find the class** (usually one class per file, extending `BaseTool`)

3. **Find `execute()`** — entry point with params dict

4. **Modify:**
   - To add new Arabic transliterations: find the dictionaries/mapping tables
   - To change max variations: modify the return list length
   - To change the algorithm: modify the generation logic

5. **Nothing else breaks** — this is a leaf tool (nothing imports it except plan_executor and tool_calling_engine which call it generically by name)

6. **Verify compile:**
   ```bash
   python -c "import py_compile; py_compile.compile('tools/shared/name_variation_generator.py')"
   ```

### Step-by-Step: Edit the Tool Calling Engine

**WARNING: This affects ALL agents in chat mode and ALL agents without JSON plans.**

1. **Open:** `tools/shared/tool_calling_engine.py`

2. **Key methods:**
   - `run()` — main loop (up to 10 iterations)
   - The system prompt that tells LLM which tools exist
   - Tool execution dispatch

3. **To change max iterations:** `config.py` → `TOOL_CALLING_MAX_ITERATIONS`

4. **To change the system prompt for tools:**
   - Find where tool definitions are formatted into the prompt
   - Modify the instruction text

5. **To change how tool results are fed back:** modify the message construction after tool execution

### Step-by-Step: Edit the Plan Executor

**WARNING: This affects ALL 14 agents that use JSON plans.**

1. **Open:** `tools/shared/plan_executor.py`

2. **Key methods:**
   - `execute_plan()` — reads JSON, iterates steps
   - `_execute_step()` — dispatches each step by action type
   - `_substitute_templates()` — replaces `{{variables}}` in params/prompts
   - `_chunked_llm_call()` — sub-agent MAP scanning for large prompts

3. **To change template substitution:** modify `_substitute_templates()`

4. **To change the chunking threshold:** find `LARGE_PROMPT_THRESHOLD = 6000` (change this number)

5. **To change how MAP sub-agents work:** modify `_chunked_llm_call()` — the sub-agent receives the assessment prompt + a chunk, and must return SMALLER output than input

6. **To add a new action type:** add a new `elif action == "my_action":` block in `_execute_step()`

---

## 16. ADDING A NEW TOOL — COMPLETE WALKTHROUGH

### Adding a New Shared Tool (Available to ALL Agents)

**Example: Adding a "web_scraper" tool**

#### Step 1: Create the tool file

Create `tools/shared/web_scraper.py`:

```python
from tools.base_tool import BaseTool


class WebScraperTool(BaseTool):
    """Scrapes a web page and returns text content."""

    def execute(self, params: dict) -> dict:
        """
        Args:
            params: {"url": "https://...", "max_chars": 5000}
        Returns:
            {"content": "scraped text", "status": "success"}
        """
        url = params.get("url", "")
        max_chars = params.get("max_chars", 5000)

        # Your implementation here
        import requests
        resp = requests.get(url, timeout=10)
        text = resp.text[:max_chars]

        return {"content": text, "status": "success", "chars": len(text)}
```

#### Step 2: Register in orchestrator.py

Open `agents/orchestrator.py`, find `_init_tool_calling_engines()` method (line ~130).

Add the tool definition after the existing tools:

```python
# --- Tool N: web_scraper ---
web_scraper_def = ToolDefinition(
    name="web_scraper",
    description="Scrape a web page and return its text content. "
                "Use for OSINT collection from public websites.",
    parameters=[
        {"name": "url", "required": True,
         "description": "Full URL to scrape (https://...)"},
        {"name": "max_chars", "required": False,
         "description": "Maximum characters to return (default: 5000)"},
    ],
    handler=self._handle_web_scraper,
)
```

#### Step 3: Add the handler method in orchestrator.py

Add a handler method to the Orchestrator class:

```python
def _handle_web_scraper(self, params: dict) -> dict:
    """Handle web_scraper tool calls."""
    from tools.shared.web_scraper import WebScraperTool
    tool = WebScraperTool()
    return tool.execute(params)
```

#### Step 4: Add to per-agent tool lists

In the same `_init_tool_calling_engines()` method, find where tools are assembled into per-agent lists. Add your tool definition to the list:

```python
shared_tools = [
    query_tool_def, expand_name_def, extract_entities_def,
    search_voter_def, search_text_db_def, analyze_def,
    datetime_def, correlate_def, translate_def,
    web_scraper_def,  # <-- ADD HERE
]
```

#### Step 5: (Optional) Add to tool_definitions.py

If you want this tool available in the tool_calling_engine's JSON schema format:

Open `tools/shared/tool_definitions.py` and add an entry to the definitions list:

```python
{
    "name": "web_scraper",
    "description": "Scrape a web page and return text content.",
    "parameters": {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "URL to scrape"},
            "max_chars": {"type": "integer", "description": "Max chars"},
        },
        "required": ["url"]
    }
}
```

#### Step 6: (Optional) Reference in a plan JSON

If you want a specific agent to call this tool in its deterministic plan:

Open `plans/{agent}.json` and add a step:

```json
{
    "id": "scrape_osint",
    "action": "tool_call",
    "tool": "web_scraper",
    "params": {"url": "{{osint_url}}", "max_chars": 10000},
    "store_as": "scraped_content",
    "description": "Scrape OSINT source"
}
```

#### Step 7: Verify

```bash
cd V2/backend
python -c "import py_compile; py_compile.compile('tools/shared/web_scraper.py')"
python -c "import py_compile; py_compile.compile('agents/orchestrator.py')"
python -c "from tools.shared.web_scraper import WebScraperTool; print('OK')"
```

---

### Adding a New Agent-Specific Search Tool

**Example: Adding a "financial_records" search tool for a new data agent**

#### Step 1: Create the tool directory and file

```
tools/agent_specific/financial/
    __init__.py
    financial_search_tool.py
```

Create `tools/agent_specific/financial/financial_search_tool.py`:

```python
from tools.agent_specific.base_agent_search_tool import BaseAgentSearchTool


class FinancialSearchTool(BaseAgentSearchTool):
    """Search financial records database."""

    def __init__(self, db_path: str):
        super().__init__(db_path)
        self.tool_name = "search_financial_records"

    def execute(self, params: dict) -> dict:
        """Search financial database.

        Args:
            params: {"query": "search terms", "max_results": 50}
        """
        query = params.get("query", "")
        max_results = params.get("max_results", 50)

        # Use parent class search (regex + scoring against text file)
        results = self._search_database(query, max_results=max_results)

        return {
            "results": results,
            "total_matches": len(results),
            "query": query,
        }
```

#### Step 2: Create the database file

Create `data/financial_db.txt` with records separated by double newlines.

#### Step 3: Add to config.py

```python
FINANCIAL_DB = os.path.join(DATA_DIR, "financial_db.txt")
```

#### Step 4: Register in orchestrator.py

In `_init_tool_calling_engines()`:

```python
from tools.agent_specific.financial.financial_search_tool import FinancialSearchTool

self._agent_search_tools["financial"] = FinancialSearchTool(Config.FINANCIAL_DB)
```

Then add the tool definition for LLM tool calling:

```python
financial_search_def = ToolDefinition(
    name="search_financial_records",
    description="Search financial records database for transactions, accounts, etc.",
    parameters=[
        {"name": "query", "required": True, "description": "Search terms"},
        {"name": "max_results", "required": False, "description": "Max results"},
    ],
    handler=lambda params: self._agent_search_tools["financial"].execute(params),
)
```

Add to the financial agent's tool list (or shared if all agents should use it).

#### Step 5: Create the agent (if new)

See "APPENDIX: HOW TO ADD A NEW DATA AGENT" at the end of the README.

---

### Adding a New Tool to an Existing Agent's Plan

**Example: I want the travel agent to also check financial records**

#### Step 1: Open the plan

Open `plans/travel.json`

#### Step 2: Add a cross-reference step

Add this step AFTER the main search steps:

```json
{
    "id": "xref_financial",
    "action": "tool_call",
    "tool": "query_agent",
    "params": {
        "agent_key": "financial",
        "query": "{{identifiers.name}}",
        "mode": "database"
    },
    "store_as": "financial_xref",
    "skip_if": "{{not identifiers.name}}",
    "description": "Cross-reference target in financial records"
}
```

#### Step 3: Reference in the compile step

Find the final compile/synthesis step and add `{{financial_xref}}` to its prompt:

```json
{
    "id": "compile",
    "action": "analyze",
    "prompt": "Compile travel findings:\n{{analysis}}\n\nFinancial cross-reference:\n{{financial_xref}}",
    "output_key": "final_report"
}
```

#### Step 4: No code changes needed

Plan JSON changes are picked up at runtime. No restart needed (plans are loaded fresh per search call).

---

### Removing a Tool

1. Remove the import and registration from `orchestrator.py`
2. Remove from tool_definitions.py (if listed there)
3. Remove from any plan JSON that references it
4. Delete the tool file
5. Verify: `python -c "import py_compile; py_compile.compile('agents/orchestrator.py')"`

---

## 17. COMPLETE "IF I CHANGE X" QUICK REFERENCE

| I Want To Change... | Files To Modify |
|--------------------|-----------------|
| What SIGINT searches for | `plans/sigint.json` → step_1 params |
| How SIGINT results look in dossier | `living_dossier.py` → `_format_sigint()` |
| What the access assessment scans for | `living_dossier.py` → `ASSESSMENT_TYPES["access"]["prompt"]` |
| The executive summary prompt | `living_dossier.py` → `generate_executive_summary()` |
| Narrative report sections (targeting) | `living_dossier.py` → `NARRATIVE_SECTIONS` (has_assessments branch) |
| Narrative report sections (LEO/trace) | `living_dossier.py` → `NARRATIVE_SECTIONS` (else branch) |
| Trace report topics | `trace_report_synthesizer.py` → `NARRATIVE_TOPICS` |
| Which agents run in pipeline | `dossier_pipeline.py` → `DATA_AGENTS` list |
| Which assessments run | `dossier_pipeline.py` → `ASSESSMENT_AGENTS` list |
| Max enrichment loops | `config.py` → `ENRICHMENT_MAX_ITERATIONS` |
| Assessment chunk size | `config.py` → `DOSSIER_CHUNK_SIZE` |
| Max concurrent agents | `dossier_pipeline.py` → `max_workers` in `_step_3_collect()` |
| LLM provider/model | `.env` → `LLM_PROVIDER`, `LLM_MODEL`, `LLM_BASE_URL` |
| Contact network format | `living_dossier.py` → `compile_contact_network()` |
| Cross-reference format | `living_dossier.py` → `compile_cross_references()` |
| Section file order | `living_dossier.py` → `SECTION_ORDER` list |
| Name transliteration rules | `name_variation_generator.py` → dictionaries |
| Phone correlation logic | `tools/agent_specific/sigint/correlation_tool.py` |
| Co-traveler matching | `tools/agent_specific/travel/co_traveler_search.py` |
| Confidence score weights | `identity_scorer.py` → field weights at top |
| Max LLM calls per search | `config.py` → `TOOL_CALLING_MAX_ITERATIONS` |
| Add a new shared tool | `orchestrator.py` → `_init_tool_calling_engines()` + new .py file |
| Add a new data agent | See APPENDIX above (10 steps) |
| Add a new assessment | See APPENDIX above (6 steps) |
| Skip enrichment for trace | `dossier_pipeline.py` → `run()` → wrap Step 4 in condition |
| Change API endpoint format | `api_server.py` → find the endpoint decorator |
| Change frontend behavior | `frontend/index.html` — single file, all JS inline |

---

*End of documentation. Last updated: 2026-05-04.*
*Covers Living Dossier architecture (current). Old report_synthesizer/targeting_report_synthesizer/agent_consolidator are DELETED.*
